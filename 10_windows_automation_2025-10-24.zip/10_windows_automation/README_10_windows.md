
# 10. Windows 자동화 — bat + run_all.py (v1, 2025-10-24)

## 구성
- `setup.bat` — 최초 설정(venv 생성 → 설치 → 마이그레이션 → 관리자 생성 → 서비스 기동)
- `reset.bat` — 서비스 중지 → DB/로그 정리 → 재마이그레이션 → 재시작
- `start.bat` — NGINX + Django + Streamlit 시작
- `stop.bat` — Django + Streamlit 중지, NGINX quit
- `run_all.py` — 오케스트레이터 (init/start/stop/status)
- `settings.env.example` — 환경변수 예시 (복사하여 `settings.env`로 사용)

## 빠른 시작
1) 프로젝트 루트에 본 패키지를 풀고, 기존 `django/` 코드가 루트에 있어야 합니다.
2) `settings.env.example` → `settings.env`로 복사 후 필요 값 수정
3) **관리자 권한**으로 `setup.bat` 실행 → 완료 후 `http://localhost/` 접속

## 명령어
```powershell
# 초기화(클린 + 관리자 생성)
venv\Scripts\python.exe run_all.py init --clean --create-admin
# 시작/중지/상태
venv\Scripts\python.exe run_all.py start
venv\Scripts\python.exe run_all.py stop
venv\Scripts\python.exe run_all.py status
```

> 기본 관리자: `admin / admin1234` (settings.env에서 변경 가능)
