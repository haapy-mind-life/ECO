
import argparse, os, subprocess, sys, time, json, signal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN_DIR = ROOT / "run"
LOG_DIR = RUN_DIR / "logs"
PID_DIR = RUN_DIR / "pids"
DJANGO_DIR = ROOT / "django"

PYTHON = str((ROOT / "venv" / "Scripts" / "python.exe").resolve()) if (ROOT / "venv" / "Scripts" / "python.exe").exists() else sys.executable

def env_from_settings():
    env_path = ROOT / "settings.env"
    env = os.environ.copy()
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"): continue
            if "=" in line:
                k, v = line.split("=", 1)
                env[k.strip()] = v.strip()
    return env

def ensure_dirs():
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    PID_DIR.mkdir(parents=True, exist_ok=True)

def _write_pid(name, pid):
    (PID_DIR / f"{name}.pid").write_text(str(pid), encoding="utf-8")

def _read_pid(name):
    p = PID_DIR / f"{name}.pid"
    if p.exists():
        try:
            return int(p.read_text().strip())
        except Exception:
            return None
    return None

def _kill_pid(pid):
    try:
        if sys.platform.startswith("win"):
            subprocess.run(["taskkill", "/F", "/PID", str(pid), "/T"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            os.kill(pid, signal.SIGTERM)
    except Exception:
        pass

def _is_running(pid):
    if pid is None: return False
    if sys.platform.startswith("win"):
        out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}"], capture_output=True, text=True)
        return str(pid) in out.stdout
    else:
        try:
            os.kill(pid, 0); return True
        except Exception:
            return False

def start_nginx(env):
    nginx_dir = Path(env.get("NGINX_DIR", r"C:\nginx"))
    nginx_exe = nginx_dir / "nginx.exe"
    nginx_conf = Path(env.get("NGINX_CONF", str(nginx_dir / "conf" / "nginx.conf")))
    if not nginx_exe.exists():
        print("[WARN] nginx.exe not found; skipping NGINX start")
        return
    # Test config
    subprocess.run([str(nginx_exe), "-t", "-c", str(nginx_conf)], check=False)
    # Try reload (if already running); else start
    r = subprocess.run([str(nginx_exe), "-s", "reload"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if r.returncode != 0:
        print("[INFO] Starting NGINX...")
        subprocess.Popen([str(nginx_exe), "-c", str(nginx_conf)], cwd=str(nginx_dir))
    else:
        print("[INFO] Reloaded NGINX")

def stop_nginx(env):
    nginx_dir = Path(env.get("NGINX_DIR", r"C:\nginx"))
    nginx_exe = nginx_dir / "nginx.exe"
    if nginx_exe.exists():
        subprocess.run([str(nginx_exe), "-s", "quit"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def start_django(env):
    ensure_dirs()
    log = open(LOG_DIR / "django.log", "a", encoding="utf-8")
    cmd = [PYTHON, str(DJANGO_DIR / "manage.py"), "runserver", "127.0.0.1:8000"]
    print("[INFO] Starting Django:", " ".join(cmd))
    p = subprocess.Popen(cmd, cwd=str(DJANGO_DIR), env=env, stdout=log, stderr=log)
    _write_pid("django", p.pid)

def start_streamlit(env):
    ensure_dirs()
    app = env.get("STREAMLIT_APP", "streamlit_app.py")
    port = env.get("STREAMLIT_PORT", "8501")
    base = env.get("STREAMLIT_BASE_PATH", "streamlit")
    addr = env.get("STREAMLIT_ADDR", "127.0.0.1")

    app_path = ROOT / app
    if not app_path.exists():
        # Create a tiny placeholder app
        app_path.write_text('import streamlit as st; st.set_page_config(page_title="FMW"); st.title("FMW Streamlit"); st.write("Placeholder app. Replace STREAMLIT_APP to your path.")', encoding="utf-8")

    log = open(LOG_DIR / "streamlit.log", "a", encoding="utf-8")
    cmd = [PYTHON, "-m", "streamlit", "run", str(app_path),
           "--server.port", str(port),
           "--server.baseUrlPath", str(base),
           "--server.address", str(addr)]
    print("[INFO] Starting Streamlit:", " ".join(cmd))
    p = subprocess.Popen(cmd, cwd=str(ROOT), env=env, stdout=log, stderr=log)
    _write_pid("streamlit", p.pid)

def stop_process(name):
    pid = _read_pid(name)
    if pid and _is_running(pid):
        print(f"[INFO] Stopping {name} (pid {pid})")
        _kill_pid(pid)
    else:
        print(f"[INFO] {name} not running")
    # clean pid file
    p = PID_DIR / f"{name}.pid"
    if p.exists():
        try: p.unlink()
        except Exception: pass

def init_project(env, clean=False, create_admin=False):
    # Optional clean
    if clean:
        db = DJANGO_DIR / "db.sqlite3"
        if db.exists():
            try: db.unlink(); print("[INFO] Deleted sqlite db")
            except Exception: pass
        shutil_dirs = [LOG_DIR, PID_DIR]
        import shutil
        for d in shutil_dirs:
            if d.exists():
                shutil.rmtree(d, ignore_errors=True)
        ensure_dirs()

    # Migrate
    cmd = [PYTHON, str(DJANGO_DIR / "manage.py"), "migrate"]
    subprocess.run(cmd, cwd=str(DJANGO_DIR), env=env, check=False)

    if create_admin:
        env2 = env.copy()
        env2["DJANGO_SUPERUSER_USERNAME"] = env.get("DJANGO_SUPERUSER_USERNAME", "admin")
        env2["DJANGO_SUPERUSER_EMAIL"] = env.get("DJANGO_SUPERUSER_EMAIL", "admin@example.com")
        env2["DJANGO_SUPERUSER_PASSWORD"] = env.get("DJANGO_SUPERUSER_PASSWORD", "admin1234")
        cmd = [PYTHON, str(DJANGO_DIR / "manage.py"), "createsuperuser", "--noinput"]
        subprocess.run(cmd, cwd=str(DJANGO_DIR), env=env2, check=False)

def main():
    parser = argparse.ArgumentParser(description="FMW Orchestrator (Windows) — NGINX + Django + Streamlit")
    sub = parser.add_subparsers(dest="cmd")

    p_init = sub.add_parser("init", help="Initialize project (migrate, optional admin)")
    p_init.add_argument("--clean", action="store_true")
    p_init.add_argument("--create-admin", action="store_true")

    sub.add_parser("start", help="Start nginx + django + streamlit")
    sub.add_parser("stop", help="Stop django + streamlit (and nginx quit)")
    sub.add_parser("status", help="Show process status")

    args = parser.parse_args()
    env = env_from_settings()
    # Ensure Django settings
    env.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.dev")

    if args.cmd == "init":
        init_project(env, clean=args.clean, create_admin=args.create_admin)
        print("[DONE] init")
    elif args.cmd == "start":
        start_nginx(env)
        start_django(env)
        start_streamlit(env)
        print("[DONE] start")
    elif args.cmd == "stop":
        stop_process("django")
        stop_process("streamlit")
        stop_nginx(env)
        print("[DONE] stop")
    elif args.cmd == "status":
        dj, st = _read_pid("django"), _read_pid("streamlit")
        print(json.dumps({"django_pid": dj, "django_running": _is_running(dj),
                          "streamlit_pid": st, "streamlit_running": _is_running(st)}, indent=2))
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
