# FMW Django Monolith — latest (2025-10-24)

## Quickstart
```bash
cd django
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export DJANGO_SETTINGS_MODULE=config.settings.dev
python manage.py migrate
python manage.py createsuperuser  # 관리자/스태프 생성
python manage.py runserver 127.0.0.1:8000
```

## Apps
- core — 도메인 모델/서비스/관리커맨드
- api — REST API (v1/dev)
- drf — 공용 시리얼라이저/CSV 렌더러/페이지네이션/예외
- ops — 운영 대시보드(UI)
- templates — 전역/공용/ops 템플릿
- scripts — YAML/사내API 적재 및 요약
- yaml — 시드 데이터(models/features/branches/taxonomy)

## 주요 엔드포인트
- `/` — Public 홈
- `/ops/` — 운영 대시보드(스태프 전용)
- `/api/v1/all?format=csv` — 전체 CSV 내보내기
- `/api/v1/<feature_group>` — 그룹별 내보내기
- `/api/dev/sync` — 동기화 트리거(POST)
- `/api/dev/runs/summary?days=N` — N일 추세

## 운영 팁
- NGINX로 **IP allowlist** 적용, 장고는 내부 통신만 허용
- PROD: `DJANGO_SETTINGS_MODULE=config.settings.prod`, `ALLOWED_HOSTS`/`CSRF_TRUSTED_ORIGINS` 필수 설정
- 변경 로그 C/U/D가 필요하면 `ChangeLog/RunStat` 모델 추가 권장
