# yaml seeds — v1
models:
  - model_name: 예시: S20/S21/A10...
features:
  - feature_group/feature/mode/value + 선택 dims(mcc/mnc/region/country/operator/sp_fci)
