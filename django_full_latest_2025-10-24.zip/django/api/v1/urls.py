from django.urls import path
from .views import AllRecordsView, GroupRecordsView
urlpatterns = [
    path("all", AllRecordsView.as_view()),
    path("<str:feature_group>", GroupRecordsView.as_view()),
]
