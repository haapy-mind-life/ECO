from datetime import datetime
from typing import Dict
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.renderers import JSONRenderer
from drf.renderers import CSVRenderer
from core.models import FeatureRecord
from drf.serializers import FeatureRecordSerializer
FILTER_FIELDS = ["model_name","solution","feature_group","feature","mcc","mnc","region","country","operator","sp_fci","mode"]
def apply_common_filters(qs, params: Dict[str, str]):
    for f in FILTER_FIELDS:
        v = params.get(f)
        if v not in (None, ""):
            qs = qs.filter(**{f: v})
    since = params.get("since")
    if since:
        try:
            dt = datetime.fromisoformat(since)
            qs = qs.filter(sync_time__date__gte=dt.date())
        except Exception:
            pass
    return qs
class AllRecordsView(APIView):
    renderer_classes = [CSVRenderer, JSONRenderer]
    def get(self, request):
        qs = apply_common_filters(FeatureRecord.objects.all(), request.GET)
        ser = FeatureRecordSerializer(qs, many=True)
        return Response(ser.data)
class GroupRecordsView(APIView):
    renderer_classes = [CSVRenderer, JSONRenderer]
    def get(self, request, feature_group: str):
        base = FeatureRecord.objects.filter(feature_group=feature_group)
        qs = apply_common_filters(base, request.GET)
        ser = FeatureRecordSerializer(qs, many=True)
        return Response(ser.data)
