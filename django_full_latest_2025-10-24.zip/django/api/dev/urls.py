from django.urls import path
from .views import SyncTriggerView, RunsSummaryView
urlpatterns = [
    path("sync", SyncTriggerView.as_view()),
    path("sync/<str:feature_group>", SyncTriggerView.as_view()),
    path("runs/summary", RunsSummaryView.as_view()),
]
