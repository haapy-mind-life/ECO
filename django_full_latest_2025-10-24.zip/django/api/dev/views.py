import threading
from datetime import timedelta
from django.utils import timezone
from django.db.models.functions import TruncDate
from django.db.models import Count
from rest_framework.views import APIView
from rest_framework.response import Response
from core.models import FeatureRecord, AuditLog
from scripts.runner import run_all
class SyncTriggerView(APIView):
    def post(self, request, feature_group=None):
        def _job():
            results = run_all(feature_group=feature_group)
            AuditLog.objects.create(actor="system", action="sync_all", detail=str(results))
        t = threading.Thread(target=_job, daemon=True); t.start()
        return Response({"status":"started"}, status=202)
class RunsSummaryView(APIView):
    def get(self, request):
        days = int(request.GET.get("days", 7))
        today = timezone.localdate()
        start = today - timedelta(days=days-1)
        qs = (FeatureRecord.objects
              .filter(sync_time__date__gte=start, sync_time__date__lte=today)
              .annotate(d=TruncDate("sync_time"))
              .values("d").annotate(cnt=Count("id")).order_by("d"))
        by_date = {row["d"]: row["cnt"] for row in qs}
        trend = []
        for i in range(days):
            d = start + timedelta(days=i)
            trend.append({"date": d.isoformat(), "created": int(by_date.get(d, 0)), "updated": 0, "deleted": 0})
        last_run = AuditLog.objects.order_by("-at").first()
        return Response({"trend": trend, "today_changes": trend[-1]["created"] if trend else 0, "today_failed_runs": 0, "last_run_at": last_run.at.isoformat() if last_run else None})
