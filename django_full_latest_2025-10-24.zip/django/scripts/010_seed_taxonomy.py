from pathlib import Path
from core.models import TaxonomyMap
from scripts.utils import load_yaml
def run(ctx=None):
    base = Path(__file__).resolve().parents[1] / "yaml"
    data = load_yaml(base / "taxonomy.yaml")
    if not data: return "no taxonomy.yaml (skipped)"
    created, updated = 0, 0
    for ns, mapping in (data or {}).items():
        for alias, canonical in (mapping or {}).items():
            obj, is_created = TaxonomyMap.objects.update_or_create(namespace=ns, alias=str(alias), defaults={"canonical": str(canonical)})
            if is_created: created += 1
            else: updated += 1
    return f"taxonomy upserted: created={created}, updated={updated}"
