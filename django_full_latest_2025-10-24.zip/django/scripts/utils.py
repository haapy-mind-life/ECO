from pathlib import Path
import yaml
def load_yaml(path: Path):
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}
def norm_list(value):
    if not value: return []
    if isinstance(value, (list, tuple)): return list(value)
    return [v.strip() for v in str(value).split(",") if v.strip()]
