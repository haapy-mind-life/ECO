import os
from django.utils import timezone
from core.models import FeatureRecord
from core.services.normalize import canonicalize
def _get_session():
    try:
        import requests; return requests.Session()
    except Exception:
        return None
def run(ctx=None):
    base = os.getenv("CORP_API_BASE"); token = os.getenv("CORP_API_TOKEN")
    if not base or not token: return "no CORP_API_* env (skipped)"
    sess = _get_session(); if_not = "requests not installed (skipped)"
    if not sess: return if_not
    url = base.rstrip("/") + "/features"
    try:
        res = sess.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=10); res.raise_for_status()
        data = res.json()
    except Exception as e:
        return f"api error: {e}"
    now = timezone.now(); upserts = 0
    for item in data or []:
        payload = {
            "model_name": item.get("model_name"), "solution": item.get("solution"),
            "feature_group": item.get("feature_group"), "feature": item.get("feature"),
            "mode": item.get("mode", "allow"), "value": item.get("value", "true"),
            "mcc": item.get("mcc"), "mnc": item.get("mnc"),
            "region": canonicalize("region", item.get("region")),
            "country": canonicalize("country", item.get("country")),
            "operator": canonicalize("operator", item.get("operator")),
            "sp_fci": canonicalize("sp_fci", item.get("sp_fci")),
        }
        FeatureRecord.objects.update_or_create(
            model_name=payload["model_name"], solution=payload["solution"],
            feature_group=payload["feature_group"], feature=payload["feature"],
            mcc=payload["mcc"], mnc=payload["mnc"], region=payload["region"],
            country=payload["country"], operator=payload["operator"], sp_fci=payload["sp_fci"],
            mode=payload["mode"], defaults={"value": payload["value"], "sync_time": now}
        ); upserts += 1
    return f"api->db upserted: {upserts} rows"
