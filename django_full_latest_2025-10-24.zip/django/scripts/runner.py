import importlib, pkgutil, os, traceback
from pathlib import Path
from typing import List, Tuple, Optional, Dict, Any
def _order_key(mname: str):
    try:
        if "_" in mname and mname.split("_", 1)[0].isdigit():
            n = int(mname.split("_", 1)[0]); return (0, n, mname)
    except Exception: pass
    return (1, 999999, mname)
def run_all(feature_group: Optional[str]=None, only: Optional[List[str]]=None, exclude: Optional[List[str]]=None, dry_run: bool=False) -> List[Tuple[str, str]]:
    base = Path(__file__).resolve().parent
    mods = [m.name for m in pkgutil.iter_modules([str(base)]) if m.ispkg is False and m.name not in ("__init__", "runner", "utils")]
    mods.sort(key=_order_key)
    env_only = os.getenv("SCRIPTS_ONLY"); env_excl = os.getenv("SCRIPTS_EXCLUDE")
    if env_only: only = [x.strip() for x in env_only.split(",") if x.strip()]
    if env_excl: exclude = [x.strip() for x in env_excl.split(",") if x.strip()]
    results: List[Tuple[str, str]] = []
    for name in mods:
        if only and not any(name.startswith(x) for x in only): continue
        if exclude and any(name.startswith(x) for x in exclude): continue
        try:
            mod = importlib.import_module(f"scripts.{name}")
            ctx: Dict[str, Any] = {"feature_group": feature_group, "dry_run": dry_run}
            if hasattr(mod, "run"):
                try: res = mod.run(ctx)  # type: ignore
                except TypeError: res = mod.run()  # type: ignore
                results.append((name, str(res)))
            else:
                results.append((name, "skipped (no run())"))
        except Exception as e:
            traceback.print_exc(); results.append((name, f"error: {e}"))
    return results
