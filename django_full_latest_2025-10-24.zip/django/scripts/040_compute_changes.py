from django.utils import timezone
from django.db.models.functions import TruncDate
from django.db.models import Count
from core.models import FeatureRecord, AuditLog
def run(ctx=None):
    today = timezone.localdate(); y = today - timezone.timedelta(days=1)
    counts = (FeatureRecord.objects.filter(sync_time__date__in=[y, today])
              .annotate(d=TruncDate("sync_time")).values("d").annotate(cnt=Count("id")))
    by_d = {row["d"]: row["cnt"] for row in counts}
    created_today = int(by_d.get(today, 0)); created_y = int(by_d.get(y, 0)); diff = created_today - created_y
    AuditLog.objects.create(actor="system", action="daily_summary", detail=f"created(today)={created_today}, created(yesterday)={created_y}, diff={diff}")
    return f"summary: today={created_today}, yesterday={created_y}, diff={diff}"
