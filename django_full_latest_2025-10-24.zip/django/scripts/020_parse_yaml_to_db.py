from pathlib import Path
from django.utils import timezone
from core.models import FeatureRecord
from scripts.utils import load_yaml
from core.services.normalize import canonicalize
def run(ctx=None):
    ctx = ctx or {}; fg_filter = ctx.get("feature_group"); dry = bool(ctx.get("dry_run"))
    base = Path(__file__).resolve().parents[1] / "yaml"
    models = load_yaml(base / "models.yaml").get("models", [])
    features = load_yaml(base / "features.yaml").get("features", [])
    now = timezone.now(); upserts = 0
    for m in models:
        for f in features:
            if fg_filter and f.get("feature_group") != fg_filter: continue
            payload = {
                "model_name": m["model_name"], "solution": m["solution"],
                "feature_group": f["feature_group"], "feature": f["feature"],
                "mode": f.get("mode", "allow"), "value": f.get("value", "true"),
                "mcc": f.get("mcc"), "mnc": f.get("mnc"),
                "region": canonicalize("region", f.get("region")),
                "country": canonicalize("country", f.get("country")),
                "operator": canonicalize("operator", f.get("operator")),
                "sp_fci": canonicalize("sp_fci", f.get("sp_fci")),
                "sync_time": now,
            }
            if dry: upserts += 1; continue
            FeatureRecord.objects.update_or_create(
                model_name=payload["model_name"], solution=payload["solution"],
                feature_group=payload["feature_group"], feature=payload["feature"],
                mcc=payload["mcc"], mnc=payload["mnc"], region=payload["region"],
                country=payload["country"], operator=payload["operator"], sp_fci=payload["sp_fci"],
                mode=payload["mode"],
                defaults={"value": payload["value"], "sync_time": now}
            )
            upserts += 1
    return f"yaml->db upserted: {upserts} rows (fg={fg_filter or 'ALL'}, dry={dry})"
