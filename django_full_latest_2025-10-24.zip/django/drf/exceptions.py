from rest_framework.views import exception_handler as drf_exception_handler
from rest_framework.response import Response
from rest_framework import status
def exception_handler(exc, context):
    resp = drf_exception_handler(exc, context)
    if resp is not None:
        data = {"code": getattr(exc, "default_code", "error"), "message": getattr(exc, "detail", str(exc)), "detail": resp.data}
        return Response(data, status=resp.status_code)
    return Response({"code":"error","message":str(exc)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
