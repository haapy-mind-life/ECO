from rest_framework import serializers
from core.models import FeatureRecord, TaxonomyMap, AuditLog
CSV_FIELDS = ["model_name","solution","feature_group","feature","mcc","mnc","region","country","operator","sp_fci","mode","value","sync_time"]
class FeatureRecordSerializer(serializers.ModelSerializer):
    class Meta:
        model = FeatureRecord
        fields = CSV_FIELDS
class TaxonomyMapSerializer(serializers.ModelSerializer):
    class Meta:
        model = TaxonomyMap
        fields = ["id", "namespace", "alias", "canonical"]
class AuditLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = AuditLog
        fields = ["id", "at", "actor", "action", "detail"]
