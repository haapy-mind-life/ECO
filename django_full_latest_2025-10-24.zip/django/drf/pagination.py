from rest_framework.pagination import LimitOffsetPagination
class OptionalLimitOffsetPagination(LimitOffsetPagination):
    default_limit = 500
    max_limit = 5000
    def get_limit(self, request):
        if request.query_params.get("limit") == "all":
            return None
        return super().get_limit(request)
