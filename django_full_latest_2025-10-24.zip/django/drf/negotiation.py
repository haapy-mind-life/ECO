from rest_framework.negotiation import DefaultContentNegotiation
class CSVFirstNegotiation(DefaultContentNegotiation):
    def select_renderer(self, request, renderers, format_suffix=None):
        renderer, media_type = super().select_renderer(request, renderers, format_suffix)
        if (getattr(renderer, "media_type", "") == "application/json"
            and any(getattr(r, "format", "") == "csv" for r in renderers)
            and request.accepted_media_type in ("*/*","text/*","")
            and request.GET.get("format") not in ("json",)):
            for r in renderers:
                if getattr(r, "format", "") == "csv":
                    return r, r.media_type
        return renderer, media_type
