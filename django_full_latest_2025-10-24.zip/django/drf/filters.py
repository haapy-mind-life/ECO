import django_filters
from core.models import FeatureRecord
class FeatureRecordFilter(django_filters.FilterSet):
    since = django_filters.DateFilter(field_name="sync_time", lookup_expr="date__gte")
    class Meta:
        model = FeatureRecord
        fields = ["model_name","solution","feature_group","feature","mcc","mnc","region","country","operator","sp_fci","mode"]
