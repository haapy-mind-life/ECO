import csv, io
from collections.abc import Mapping
from rest_framework.renderers import BaseRenderer
CSV_HEADERS = ["model_name","solution","feature_group","feature","mcc","mnc","region","country","operator","sp_fci","mode","value","sync_time"]
class CSVRenderer(BaseRenderer):
    media_type = "text/csv"
    format = "csv"
    charset = "utf-8"
    def render(self, data, accepted_media_type=None, renderer_context=None):
        if data is None:
            return ""
        if not isinstance(data, (list, tuple)):
            return str(data)
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=CSV_HEADERS, extrasaction="ignore")
        writer.writeheader()
        for item in data:
            if isinstance(item, Mapping):
                row = {k: item.get(k, "") for k in CSV_HEADERS}
            else:
                row = {k: getattr(item, k, "") for k in CSV_HEADERS}
            writer.writerow(row)
        return buf.getvalue()
