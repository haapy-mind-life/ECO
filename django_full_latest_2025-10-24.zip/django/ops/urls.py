from django.urls import path
from .views import home, changes, records, sync_view
urlpatterns = [
    path("", home, name="ops-home"),
    path("changes", changes, name="ops-changes"),
    path("records", records, name="ops-records"),
    path("sync", sync_view, name="ops-sync"),
]
