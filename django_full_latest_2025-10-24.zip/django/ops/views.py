import threading
from datetime import timedelta
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.utils import timezone
from core.models import FeatureRecord, AuditLog
from scripts.runner import run_all
def _yesterday_range():
    t = timezone.localdate()
    y = t - timedelta(days=1)
    return y, y
@staff_member_required
def home(request):
    today_d = timezone.localdate()
    y, _ = _yesterday_range()
    today_cnt = FeatureRecord.objects.filter(sync_time__date=today_d).count()
    y_cnt = FeatureRecord.objects.filter(sync_time__date=y).count()
    last_run = AuditLog.objects.order_by("-at").first()
    ctx = {"title": "FMW Ops — Overview", "today_cnt": today_cnt, "y_cnt": y_cnt, "last_run_at": last_run.at if last_run else None, "default_days": 14}
    return render(request, "ops/home.html", ctx)
@staff_member_required
def changes(request):
    start_str = request.GET.get("start")
    end_str = request.GET.get("end")
    if start_str and end_str:
        try:
            start = timezone.datetime.fromisoformat(start_str).date()
            end = timezone.datetime.fromisoformat(end_str).date()
        except Exception:
            start, end = _yesterday_range()
    else:
        start, end = _yesterday_range()
    qs = FeatureRecord.objects.filter(sync_time__date__gte=start, sync_time__date__lte=end).order_by("-sync_time")[:1000]
    return render(request, "ops/changes.html", {"title": "Daily Changes (created-based)", "rows": qs, "start": start, "end": end})
@staff_member_required
def records(request):
    params = {k: request.GET.get(k) for k in ["model_name","solution","feature_group","feature","mcc","mnc","region","country","operator","sp_fci","mode"]}
    qs = FeatureRecord.objects.all()
    for k, v in params.items():
        if v: qs = qs.filter(**{k: v})
    qs = qs.order_by("model_name","feature_group","feature")[:500]
    return render(request, "ops/records.html", {"title": "Records Browser", "rows": qs, "params": params})
@staff_member_required
def sync_view(request):
    if request.method == "POST":
        def _job():
            results = run_all()
            AuditLog.objects.create(actor="ops", action="sync_all", detail=str(results))
        t = threading.Thread(target=_job, daemon=True); t.start()
        messages.success(request, "동기화를 시작했습니다. (백그라운드 실행)")
        return redirect("ops-sync")
    last_run = AuditLog.objects.order_by("-at").first()
    return render(request, "ops/sync.html", {"title": "Sync & Maintenance", "last_run_at": last_run.at if last_run else None})
