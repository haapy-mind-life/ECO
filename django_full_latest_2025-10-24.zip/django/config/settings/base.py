from pathlib import Path
import os

DJ_ROOT = Path(__file__).resolve().parents[2]
BASE_DIR = DJ_ROOT

def env_bool(key: str, default: bool=False) -> bool:
    val = os.getenv(key)
    if val is None: return default
    return val.lower() in ("1", "true", "yes", "on")

def env_list(key: str, default=None):
    if default is None: default = []
    raw = os.getenv(key, "")
    items = [x.strip() for x in raw.split(",") if x.strip()]
    return items or default

SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key")
DEBUG = env_bool("DEBUG", False)
ALLOWED_HOSTS = env_list("ALLOWED_HOSTS", ["localhost","127.0.0.1"])
CSRF_TRUSTED_ORIGINS = env_list("CSRF_TRUSTED_ORIGINS", [])

LANGUAGE_CODE = "ko-kr"
TIME_ZONE = "Asia/Seoul"
USE_I18N = True
USE_TZ = True

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "django_filters",
    "core",
    "api",
    "ops",
    "drf",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [DJ_ROOT / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"

if os.getenv("DATABASE_URL"):
    from urllib.parse import urlparse
    url = urlparse(os.getenv("DATABASE_URL"))
    if url.scheme.startswith("postgis") or url.scheme.startswith("postgres"):
        ENGINE = "django.db.backends.postgresql"
    elif url.scheme.startswith("mysql"):
        ENGINE = "django.db.backends.mysql"
    else:
        ENGINE = "django.db.backends.sqlite3"
    DB_NAME = url.path[1:] or (DJ_ROOT / "db.sqlite3")
    DATABASES = {
        "default": {
            "ENGINE": ENGINE,
            "NAME": DB_NAME,
            "USER": url.username or "",
            "PASSWORD": url.password or "",
            "HOST": url.hostname or "",
            "PORT": url.port or "",
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": DJ_ROOT / "db.sqlite3",
        }
    }

STATIC_URL = "static/"
STATICFILES_DIRS = [DJ_ROOT / "static"]
STATIC_ROOT = os.getenv("STATIC_ROOT", str(DJ_ROOT / ".static_collected"))
MEDIA_URL = "media/"
MEDIA_ROOT = os.getenv("MEDIA_ROOT", str(DJ_ROOT / "media"))

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

REST_FRAMEWORK = {
    "DEFAULT_FILTER_BACKENDS": ["django_filters.rest_framework.DjangoFilterBackend"],
    "DEFAULT_RENDERER_CLASSES": [
        "rest_framework.renderers.JSONRenderer",
    ],
    "DEFAULT_PAGINATION_CLASS": "drf.pagination.OptionalLimitOffsetPagination",
    "EXCEPTION_HANDLER": "drf.exceptions.exception_handler",
    # "DEFAULT_CONTENT_NEGOTIATION_CLASS": "drf.negotiation.CSVFirstNegotiation",  # optional
}

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "simple": {"format": "[%(levelname)s] %(asctime)s %(name)s: %(message)s"},
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "simple"},
    },
    "root": {"handlers": ["console"], "level": LOG_LEVEL},
}

if not DEBUG:
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    SECURE_SSL_REDIRECT = env_bool("SECURE_SSL_REDIRECT", True)
    SESSION_COOKIE_SECURE = env_bool("SESSION_COOKIE_SECURE", True)
    CSRF_COOKIE_SECURE = env_bool("CSRF_COOKIE_SECURE", True)
    SECURE_HSTS_SECONDS = int(os.getenv("SECURE_HSTS_SECONDS", "3600"))
    SECURE_HSTS_INCLUDE_SUBDOMAINS = env_bool("SECURE_HSTS_INCLUDE_SUBDOMAINS", False)
    SECURE_HSTS_PRELOAD = env_bool("SECURE_HSTS_PRELOAD", False)
    X_FRAME_OPTIONS = os.getenv("X_FRAME_OPTIONS", "DENY")
