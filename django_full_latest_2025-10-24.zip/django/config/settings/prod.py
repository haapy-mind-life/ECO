from .base import *
DEBUG = False
assert ALLOWED_HOSTS, "ALLOWED_HOSTS must be set in production"
