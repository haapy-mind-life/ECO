from .base import *
DEBUG = True
if not ALLOWED_HOSTS:
    ALLOWED_HOSTS = ["*"]
