from django.contrib import admin
from django.urls import path, include
from .views import home

urlpatterns = [
    path("", home),
    path("healthz", lambda r: __import__("django.http").http.HttpResponse("ok", content_type="text/plain")),
    path("admin/", admin.site.urls),
    path("api/v1/", include("api.v1.urls")),
    path("api/dev/", include("api.dev.urls")),
    path("ops/", include("ops.urls")),
]
