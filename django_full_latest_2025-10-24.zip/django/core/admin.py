from django.contrib import admin
from django.http import HttpResponse
import csv
from .models import FeatureRecord, TaxonomyMap, AuditLog
@admin.action(description="선택 행 CSV로 내보내기")
def export_selected_csv(modeladmin, request, queryset):
    headers = ["model_name","solution","feature_group","feature","mcc","mnc","region","country","operator","sp_fci","mode","value","sync_time"]
    resp = HttpResponse(content_type="text/csv; charset=utf-8")
    resp["Content-Disposition"] = "attachment; filename=feature_records.csv"
    w = csv.writer(resp); w.writerow(headers)
    for obj in queryset:
        w.writerow([getattr(obj, h, "") for h in headers])
    return resp
@admin.register(FeatureRecord)
class FeatureRecordAdmin(admin.ModelAdmin):
    list_display = ("model_name","solution","feature_group","feature","mode","country","operator","sync_time")
    list_filter  = ("solution","feature_group","mode","country","operator")
    search_fields= ("model_name","feature_group","feature","country","operator","sp_fci")
    actions = [export_selected_csv]
@admin.register(TaxonomyMap)
class TaxonomyMapAdmin(admin.ModelAdmin):
    list_display = ("namespace","alias","canonical")
    search_fields = ("namespace","alias","canonical")
@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ("at","actor","action")
    search_fields = ("actor","action","detail")
