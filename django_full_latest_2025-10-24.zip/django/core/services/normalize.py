from typing import Optional
from core.models import TaxonomyMap
def canonicalize(namespace: str, value: Optional[str]) -> Optional[str]:
    if not value:
        return value
    try:
        m = TaxonomyMap.objects.get(namespace=namespace, alias=value)
        return m.canonical
    except TaxonomyMap.DoesNotExist:
        return value
