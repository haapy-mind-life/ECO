from typing import Iterable, Optional, Tuple
from core.models import FeatureRecord
DIM_ORDER = ["mcc","mnc","operator","country","region","sp_fci"]
def _specificity(rec: FeatureRecord) -> int:
    return sum(1 for d in DIM_ORDER if getattr(rec, d, None))
def _tie_weight(rec: FeatureRecord) -> Tuple[int,int,int,int,int,int]:
    return (
        1 if (rec.mcc and rec.mnc) else 0,
        1 if rec.mcc else 0,
        1 if rec.operator else 0,
        1 if rec.country else 0,
        1 if rec.region else 0,
        1 if rec.sp_fci else 0,
    )
def choose_best(records: Iterable[FeatureRecord]) -> Optional[FeatureRecord]:
    priority = {"block":2, "allow":1, "none":0}
    best = None
    for r in records:
        if best is None:
            best = r; continue
        bp, rp = priority.get(best.mode, -1), priority.get(r.mode, -1)
        if rp != bp:
            best = r if rp > bp else best; continue
        bs, rs = _specificity(best), _specificity(r)
        if rs != bs:
            best = r if rs > bs else best; continue
        if _tie_weight(r) != _tie_weight(best):
            best = r if _tie_weight(r) > _tie_weight(best) else best; continue
        if r.sync_time and best.sync_time and r.sync_time > best.sync_time:
            best = r
    return best
