import re
from django.core.exceptions import ValidationError
_re_digits = re.compile(r"^[0-9]+$")
_re_iso2   = re.compile(r"^[A-Z]{2}$")
_re_region = re.compile(r"^[A-Z0-9_\-]{2,10}$")
def validate_mcc(value: str):
    if value in (None, ""): return
    if not (_re_digits.match(value) and len(value) == 3):
        raise ValidationError("mcc must be 3 digits (e.g., '450').")
def validate_mnc(value: str):
    if value in (None, ""): return
    if not (_re_digits.match(value) and len(value) in (2,3)):
        raise ValidationError("mnc must be 2~3 digits (e.g., '05' or '450').")
def validate_country_iso2(value: str):
    if value in (None, ""): return
    if not _re_iso2.match(value):
        raise ValidationError("country must be ISO-2 uppercase (e.g., 'KR').")
def validate_region(value: str):
    if value in (None, ""): return
    if not _re_region.match(value):
        raise ValidationError("region must be uppercase token (e.g., 'EU','APAC').")
