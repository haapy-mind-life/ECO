from django.db.models import TextChoices
class Mode(TextChoices):
    ALLOW = "allow", "Allow"
    BLOCK = "block", "Block"
    NONE  = "none",  "None"
class Solution(TextChoices):
    SLSI = "slsi", "SLSI"
    MTK  = "mtk",  "MTK"
