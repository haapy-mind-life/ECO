from django.db import models
class AuditLog(models.Model):
    at = models.DateTimeField(auto_now_add=True)
    actor = models.CharField(max_length=64, default="system")
    action = models.CharField(max_length=64)
    detail = models.TextField(blank=True, default="")
    class Meta:
        indexes = [models.Index(fields=["at","action"])]
    def __str__(self):
        return f"[{self.at}] {self.actor} {self.action}"
