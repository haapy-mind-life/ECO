from django.db import models
from django.utils import timezone
from core.choices import Mode, Solution
from core.validators import validate_mcc, validate_mnc, validate_country_iso2, validate_region
class FeatureRecord(models.Model):
    model_name   = models.CharField(max_length=64)
    solution     = models.CharField(max_length=16, choices=Solution.choices)
    feature_group= models.CharField(max_length=64)
    feature      = models.CharField(max_length=64)
    mcc      = models.CharField(max_length=8, null=True, blank=True, validators=[validate_mcc])
    mnc      = models.CharField(max_length=8, null=True, blank=True, validators=[validate_mnc])
    region   = models.CharField(max_length=16, null=True, blank=True, validators=[validate_region])
    country  = models.CharField(max_length=8, null=True, blank=True, validators=[validate_country_iso2])
    operator = models.CharField(max_length=64, null=True, blank=True)
    sp_fci   = models.CharField(max_length=64, null=True, blank=True)
    mode   = models.CharField(max_length=16, choices=Mode.choices)
    value  = models.CharField(max_length=256)
    sync_time = models.DateTimeField(default=timezone.now)
    class Meta:
        indexes = [
            models.Index(fields=["feature_group","feature"]),
            models.Index(fields=["model_name","solution"]),
            models.Index(fields=["country","operator"]),
            models.Index(fields=["mcc","mnc"]),
            models.Index(fields=["sync_time"]),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=["model_name","solution","feature_group","feature","mcc","mnc","region","country","operator","sp_fci","mode"],
                name="uniq_feature_record_key"
            )
        ]
    def __str__(self):
        return f"{self.model_name}/{self.solution}/{self.feature_group}/{self.feature} [{self.mode}]"
