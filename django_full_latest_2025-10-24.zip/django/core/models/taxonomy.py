from django.db import models
class TaxonomyMap(models.Model):
    namespace = models.CharField(max_length=32)
    alias     = models.CharField(max_length=128)
    canonical = models.CharField(max_length=128)
    class Meta:
        unique_together = ("namespace","alias")
        indexes = [
            models.Index(fields=["namespace","alias"]),
            models.Index(fields=["namespace","canonical"]),
        ]
    def __str__(self):
        return f"{self.namespace}:{self.alias} -> {self.canonical}"
