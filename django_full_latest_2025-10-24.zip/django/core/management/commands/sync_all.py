from django.core.management.base import BaseCommand
from django.db import transaction
from scripts.runner import run_all
from core.models import AuditLog
class Command(BaseCommand):
    help = "Run all scripts in django/scripts/* (run() function), record AuditLog"
    def handle(self, *args, **opts):
        with transaction.atomic():
            results = run_all()
            AuditLog.objects.create(actor="system", action="sync_all", detail=str(results))
        for name, res in results:
            self.stdout.write(self.style.SUCCESS(f"{name}: {res}"))
