
# 09. NGINX 설정 — 최신 업데이트 (v1, 2025-10-24)

이 패키지는 **Windows(C:\nginx)** 환경을 우선으로 한 간단 설정과 배포 스크립트를 제공합니다.
- Windows: `windows/nginx.conf`를 **그대로** `C:\nginx\conf\nginx.conf`로 복사하면 동작합니다.
- Linux: `linux/fmw_nginx_minimal.conf`는 서버 블록 1개짜리 최소 예시입니다.

## 구조
- `windows/nginx.conf` — 전체 nginx.conf (HTTP, 최소 구성)
- `windows/apply_config.bat` — `nginx.conf` 백업 → 복사 → 테스트 → **reload**
- `windows/streamlit_config_example.toml` — prefix(`/streamlit/`) 환경용 예시
- `linux/fmw_nginx_minimal.conf` — Linux용 최소 서버블록 예시(HTTP)
- `README_windows.md`, `README_linux.md` — 상세 사용법

**권장 흐름(Windows):**
1) `windows/nginx.conf`를 필요시 수정(정적 경로 등)
2) `windows/apply_config.bat` 실행(관리자 권한) → 자동 백업/검증/재적용
3) 브라우저에서 확인: `http://localhost/`, `/api/v1/all`, `/streamlit/`
