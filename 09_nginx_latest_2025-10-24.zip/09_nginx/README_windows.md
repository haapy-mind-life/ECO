
# Windows용 가이드 (C:\nginx)

## 빠른 적용
1) `windows\nginx.conf` 확인 후 정적 경로(`/static/`)를 환경에 맞춰 수정
2) **관리자 권한**으로 `windows\apply_config.bat` 실행
   - 기존 `nginx.conf`를 `nginx.conf.YYYYMMDD_HHMMSS.bak`로 백업
   - 새 설정 복사 → `nginx -t` 테스트 → `nginx -s reload`
3) 확인: `http://localhost/`, `/api/v1/all`, `/streamlit/`

## Streamlit Prefix 모드
`%USERPROFILE%\.streamlit\config.toml`에 아래 설정:
```toml
[server]
baseUrlPath = "streamlit"
address = "127.0.0.1"
enableXsrfProtection = true
```

## 자주 묻는 질문
- **정적 404** → `collectstatic` 결과 경로(`C:\nginx\static`)와 권한 확인
- **reload 실패** → 서비스 미기동일 수 있음 → `start "" C:\nginx\nginx.exe`
- **포트 충돌** → 80 포트를 사용하는 프로그램 종료 또는 포트 변경
