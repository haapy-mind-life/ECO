
# Linux용 간단 설정

```bash
sudo cp linux/fmw_nginx_minimal.conf /etc/nginx/sites-available/fmw.conf
sudo ln -s /etc/nginx/sites-available/fmw.conf /etc/nginx/sites-enabled/fmw.conf
sudo nginx -t && sudo systemctl reload nginx
```
- Streamlit은 `~/.streamlit/config.toml`에서 `baseUrlPath="streamlit"` 권장.
