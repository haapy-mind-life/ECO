# 문서 개요
- **문서 목적**: FMW 시스템을 빠르게 이해·운영·개선할 수 있도록, 기존 산출물을 하나의 일관된 운영 가이드로 재구성
- **대상 독자**: 개발자(Dev 20) / 운영자(Ops 3) / 이해관계자
- **버전**: 4.0 재구성본 · **작성일**: 2025-10-25 · **소스 기준일**: 2025-10-26 (원문)
- **문서 소유**: FMW 팀 · **Contributing**: PR/Change 요청은 `/docs/CHANGE_LOG.md` 규칙 준수

---

## 0. 원페이지 요약 (One‑Page)
**비전/성과지표(KPI)**
- 채택: 주간 활성 ≥70%
- 성능: 홈 <1초, 주요 조회 <5초
- 신선도: 동기화 실패율 <2%
- 운영: 일일 점검 ≤30분

**핵심 설계 원칙**
- 사용성 우선 · 스냅샷 기반 체감속도 · 시각화 중심 · Taxonomy 표준화 · 확장성 고려

**주요 컴포넌트**
- Nginx(게이트웨이) → Django(API/운영) → Streamlit(UI) → DB(SQLite→Postgres)
- 오케스트레이션: `run_all.py` / 배치: `setup|start|stop|reset.bat`

**안전장치(현재→미래)**
- 현재: IP 허용목록 + 로컬 바인딩
- 제안: IPLogMiddleware, Postgres(ON CONFLICT), SSO+RBAC, 컨테이너화

---

## 1. 빠른 시작 (Quickstart)
### 1.1 개발자(Dev)
- 데이터 조회: `GET /api/v1/all?model_name=<M>&limit=100` (기본 `text/csv`, `?format=json` 지원)
- 요약 지표: `GET /api/dev/runs/summary?days=14`
- 로컬 분석: CSV 내보내기 후 파이썬/엑셀로 필터링

### 1.2 운영자(Ops)
```bat
python run_all.py status
python run_all.py stop && python run_all.py start
```
- 기대: Nginx 뒤에서만 접근 가능, PID 추적 정상
- 배치 스크립트: `setup.bat`(최초 설치) · `start.bat`(시작) · `stop.bat`(정지) · `reset.bat`(정리)

---

## 2. 아키텍처 (C4 관점 요약)
### 2.1 컨텍스트/컨테이너
- **Nginx(80)**: 유일한 진입점, 리버스 프록시/보안 게이트웨이
- **Django(127.0.0.1:8000)**: API, /ops, Admin
- **Streamlit(127.0.0.1:8501)**: 사용자 UI
- **DB(SQLite→Postgres)**: 영속성 계층
- **run_all.py**: 생명주기 오케스트레이션

### 2.2 품질속성 ↔ 전술 매핑
- 성능: 스냅샷 UI(DataManager) · 요약 API(`/api/dev/runs/summary`) · 인덱싱
- 보안: Nginx IP Allowlist · 루프백 바인딩
- 운영성: 표준 로그/ PID 디렉토리 · 단순 배치 스크립트
- 무결성: `identity_hash` 업서트 · TaxonomyMap · AuditLog

---

## 3. 데이터 모델 & ETL
### 3.1 핵심 테이블
- **FeatureRecord**: 기능 상태의 정규화 원장
- **TaxonomyMap**: 별칭→표준명 매핑
- **AuditLog**: 생성/수정/삭제 이력 원장

### 3.2 무결성 키 — `identity_hash`
- 정규화된 식별 필드를 SHA‑256으로 해싱 → UNIQUE 인덱스 → 멱등 업서트 보장

### 3.3 데이터 생명주기(ETL)
1) 추출: 내부 API·YAML → 2) 정규화: TaxonomyMap → 3) 해싱: `identity_hash` → 4) 업서트 → 5) 감사: AuditLog

---

## 4. API 레퍼런스 (필수 최소)
### 4.1 공개 읽기 전용 `/api/v1` (CSV 우선)
- **GET `/api/v1/all`**: 모든 FeatureRecord 조회
  - 파라미터: `model_name, solution, since, limit, offset, order_by, dims...`
- **GET `/api/v1/{group}`**: 그룹별 편의 조회

### 4.2 운영 제어 `/api/dev`
- **POST `/api/dev/sync`**: 비동기 동기화 트리거(202)
- **GET `/api/dev/runs/summary?days=N`**: 일별 CRUD 집계 반환

### 4.3 예시
```bash
curl "http://<host>/api/v1/all?model_name=<M>&limit=100" -o export.csv
curl "http://<host>/api/dev/runs/summary?days=14"
```

---

## 5. 프레젠테이션(UI) 설계
- **정보구조**: 사이드바 내비게이션 · 4대 핵심 뷰(개요/히스토리/탐색/DEV)
- **DataManager 스냅샷 전략**
  - records.csv, runs_summary.json 로컬 캐시
  - 장점: 인메모리 성능·복원력(백엔드 다운시 마지막 스냅샷 제공)
  - 트레이드오프: 실시간성 낮음(일일 동기화)

---

## 6. 보안 모델
- **계층 1: 네트워크 경계** — Nginx `allowlist.conf` (기본 `deny all`)
- **계층 2: 애플리케이션 강화** — Django/Streamlit 루프백 바인딩(127.0.0.1)
- **권장 개선** — `IPLogMiddleware` + AccessLog 테이블(요청·사용자·XFF·상태코드)

---

## 7. 운영 프레임워크(Windows)
### 7.1 run_all.py
- 환경 로딩(settings.env) · 디렉토리(run/logs/pids/snapshots) · 프로세스 관리(start/stop/status/clean)

### 7.2 생명주기 스크립트
| 스크립트 | 목적 | 사용 시점 | 핵심 동작 |
|---|---|---|---|
| setup.bat | 최초 설치 | 새 서버 초기화 | venv·의존성·settings.env·DB init |
| start.bat | 서비스 시작 | 일일 시작/재부팅 후 | `python run_all.py start` |
| stop.bat | 서비스 정지 | 유지보수/정상 종료 | `python run_all.py stop` |
| reset.bat | 정리 | 로그/PID 청소 | 서비스 정지→clean→알림 |

---

## 8. 운영 점검 & 모니터링(체크리스트)
- [ ] `allowlist.conf` 최신 사내 IP, 기본 `deny all`
- [ ] Django/Streamlit 루프백 바인딩 확인
- [ ] DB `identity_hash` UNIQUE 인덱스 존재
- [ ] `/api/dev/sync` 202 수신·실패 알림 로깅
- [ ] `/api/dev/runs/summary`로 대시보드 초기 로드
- [ ] 스냅샷 생성/갱신 주기 확인(records.csv, runs_summary.json)
- [ ] 디렉토리 권한/회전(run/, logs/, pids/, snapshots/)
- [ ] 배치 스크립트 4종 동작 검증
- [ ] Prod: DEBUG off · Secret 관리
- [ ] AccessLog 스키마/보존기간 정책

---

## 9. 트러블슈팅
- **증상**: UI는 열리나 데이터가 오래됨 → **점검**: DataManager 스케줄·스냅샷 타임스탬프→ **조치**: `/api/dev/sync` 확인 후 스냅샷 갱신
- **증상**: 8000/8501 직접 접근 가능 → **점검**: 서비스 바인딩/방화벽 → **조치**: 루프백 재설정, Nginx 정책 재적용
- **증상**: 중복 레코드 발생 → **점검**: `identity_hash` 인덱스·정규화 로직 → **조치**: NULL 처리·해싱 함수 검증

---

## 10. 로드맵
- **즉시(1단계)**: IPLogMiddleware 도입, SQLite→Postgres 전환(ON CONFLICT)
- **중기(2단계)**: SSO 도입, RBAC 매트릭스(Dev/Operator/Viewer)
- **장기(3단계)**: 컨테이너화, 로드밸런싱/DB 복제, 관측성(구조화 로그·메트릭)

---

## 부록
### A. 용어집(Glossary)
- **identity_hash**: 정규화된 식별 필드 해시로 업서트 멱등성 보장
- **TaxonomyMap**: 별칭을 표준명으로 매핑하는 표
- **DataManager**: 스냅샷 생성/캐시 담당 컴포넌트

### B. 설정 키 가이드(settings.env)
- `DJANGO_DEBUG`, `DJANGO_SECRET_KEY`, DB 접속, Nginx 포함 설정 포인트

### C. ERD(개요)
- FeatureRecord ↔ AuditLog(1:N)
- TaxonomyMap: 표준화 참조(별칭→표준)

### D. 변경 이력(CHANGE_LOG 발췌 규칙)
- 제목(요약) · 이슈/PR 링크 · 영향범위(Dev/Ops/UI/DB) · 롤백포인트 · 릴리즈 날짜

