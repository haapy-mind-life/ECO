
# 03. Architecture Overview (C4) — 최신 (v2, 2025-10-24)

**5줄 요약**
1) 구조: **NGINX(프록시/IP 허용) → Django(API/OPS/Admin) → DB → Streamlit(UI)**  
2) 데이터는 **매일 1회 스냅샷**으로 캐싱, 사용자는 **빠른 조회**(CSV/JSON)  
3) 보안: **허용 IP만** 접근, Django/Streamlit은 **로컬 바인딩(127.0.0.1)**  
4) 대상: **개발자 20명**(1차) → 검증 후 **그룹 전체** 확장  
5) 운영: `/ops`에서 상태·히스토리, `/api/dev`로 수동 동기화/요약 제공

---

## 목차
- [L1. System Context](#l1-system-context)
- [L2. Container](#l2-container)
- [L3. Component (Django 중심)](#l3-component-django-중심)
- [데이터 흐름(스냅샷/조회)](#데이터-흐름스냅샷조회)
- [엔드포인트 맵](#엔드포인트-맵)
- [보안·운영·배포](#보안운영배포)
- [변경 이력](#변경-이력)

---

## L1. System Context

```mermaid
graph TD
  Dev[개발자 20명] -->|/streamlit| Nginx
  Ops[운영자 3명] -->|/ops /admin| Nginx
  Nginx{NGINX (IP Allowlist)} --> Django[(Django)]
  Nginx --> Streamlit[(Streamlit)]
  Django --> DB[(DB: FeatureRecord, TaxonomyMap, AuditLog)]
  Scripts[사내 API 파서 / YAML] --> Django
  Note[사내 Git 정적 페이지/위키] --> Dev
```

- **개발자(일반 사용자)**: 모델/피처 조회, 히스토리 확인(스냅샷 기반)  
- **운영자**: `/ops`에서 상태·요약·변경 목록 확인, 수동 동기화  
- **사내 API/YAML**: 일일 동기화의 **데이터 원천**

---

## L2. Container

```mermaid
graph LR
  subgraph Client
    U1[브라우저]
  end

  subgraph Server (Windows)
    NG[Nginx: 80]
    DJ[Django: 127.0.0.1:8000]
    ST[Streamlit: 127.0.0.1:8501 (base=/streamlit)]
    DB[(SQLite→Postgres)]
    RUN[run_all.py + BAT]
  end

  U1 --> NG
  NG -->|/admin /ops /api| DJ
  NG -->|/streamlit/ (WS)| ST
  DJ --> DB
  RUN --> NG
  RUN --> DJ
  RUN --> ST
```

- **Nginx**: 단일 진입점, **IP Allowlist** 적용, `/streamlit/` WebSocket 업그레이드  
- **Django**: `/api/v1`, `/api/dev`, `/ops`, `/admin` 제공  
- **DB**: `FeatureRecord`, `TaxonomyMap`, `AuditLog` 보관  
- **Streamlit**: 스냅샷 기반 UI(홈 오버뷰, 히스토리, 상세 필터/시각화)  
- **run_all.py/BAT**: 시작·중지·초기화 자동화

---

## L3. Component (Django 중심)

```mermaid
graph TD
  subgraph Django
    V1[api.v1
(ListView/Filter/CSV)]
    DV[api.dev
(sync, runs/summary)]
    OPS[ops
(staff dashboard)]
    ADM[admin
(Django Admin)]
    DRF[drf.renderers.CSVRenderer]
    MOD[core.models
(FeatureRecord/Taxonomy/Audit)]
    SVC[core.services
(정규화/업서트/집계)]
    CMD[management.commands
(sync_all/compute_runs_summary)]
  end
  V1 --> DRF
  DV --> CMD
  OPS --> SVC
  SVC --> MOD
  V1 --> MOD
```

- `api.v1`: **조회 전용**(CSV 기본, JSON 옵션), 공통 필터 지원  
- `api.dev`: **운영/개발 전용**(동기화 트리거, N일 요약)  
- `ops`: 요약/변경 리스트/수동 동기화 버튼  
- `admin`: 관리자 CRUD/점검  
- `CSVRenderer`: 대용량 다운로드 친화

---

## 데이터 흐름(스냅샷/조회)

```mermaid
sequenceDiagram
  participant Sch as Scheduler
  participant Parser as 사내API 파서/YAML
  participant DJ as Django
  participant DB as DB
  participant ST as Streamlit DataManager

  Sch->>Parser: 매일 1회 실행
  Parser->>DJ: 정규화된 레코드 전달
  DJ->>DB: 업서트(FeatureRecord/Taxonomy/Audit)
  ST->>DJ: /api/dev/runs/summary (신선도 확인)
  ST->>DB: 스냅샷 로드(records.csv/json)
  Note over ST: 사용자 조회 시<br/>스냅샷 사용
```

- **개발 단계**: 수동 동기화 버튼(시간 지정 가능) + 시뮬레이션 제거(실 API 연동)  
- **운영 단계**: 스케줄러만 1일 1회, 실패 시 알림/배지

---

## 엔드포인트 맵

### 공개 조회 (v1)
- `GET /api/v1/all` — 전체 레코드(필터 지원, **CSV 기본**, `?format=json` 선택)  
- `GET /api/v1/{feature_group}` — 그룹 단위(필터 동일)

> 공통 필터: `model_name, solution, feature_group, feature, mode, mcc, mnc, region, country, operator, sp_fci, since`

### 개발·운영 (dev)
- `POST /api/dev/sync` — 전체 동기화(개발/운영자 전용)  
- `POST /api/dev/sync/{feature_group}` — 그룹별 동기화  
- `GET /api/dev/runs/summary?days=N` — **N일 변경 추세** 시계열

### 운영 대시보드 (ops)
- `/ops/overview` — 오늘/어제/N일 요약  
- `/ops/changes` — 일별 CRUD 상세(검색/필터/CSV)  
- `/ops/sync` — 수동 동기화

---

## 보안·운영·배포

- **보안**
  - **IP Allowlist**: `allow 192.168.0.0/16; ...` → `deny all;`
  - Django/Streamlit **로컬 바인딩**, 외부 직접 접근 차단
- **운영**
  - `/ops`에서 신선도·변경 집계·수동 sync
  - 로그/PID 표준화: `run/logs/*`, `run/pids/*`
- **배포(Windows)**
  - **Nginx**: `C:\nginx` (09 문서)  
  - **자동화**: `run_all.py` + `setup/reset/start/stop.bat` (10 문서)  
  - Streamlit: `--server.baseUrlPath=/streamlit`

---

## 변경 이력
- **v2 (2025-10-24)**: C4(L1~L3) 간단 도식 + 스냅샷/엔드포인트 정리 + 배포/운영 명시
- **v1**: 초기 개요
