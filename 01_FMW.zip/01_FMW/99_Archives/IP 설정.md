좋습니다, 선생님. **Streamlit까지 포함한 IP 수집 → Django DB 저장 → OPS 대시보드 출력** 흐름으로 문서와 코드 모두 한 번에 정리해드립니다. (핵심만 바로 적용 가능하도록 스니펫 위주)

# 1) NGINX (원 IP 전달 — 모든 프록시에 공통)

```nginx
# /api/, /ops/, /admin/, /streamlit/ 공통으로 아래 3줄 포함
proxy_set_header X-Real-IP          $remote_addr;
proxy_set_header X-Forwarded-For    $proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto  $scheme;
```

- 이미 구성되어 있으면 그대로 사용하세요. (same-origin 호출이므로 CORS 불필요)
    

---

# 2) Django — AccessLog 확장(스트림릿 구분 + UA 저장)

## 2-1) 모델 (src, ua 필드 추가)

```python
# core/models/access_log.py
from django.conf import settings
from django.db import models

class AccessLog(models.Model):
    ip = models.GenericIPAddressField()
    path = models.TextField()
    method = models.CharField(max_length=8)
    status = models.IntegerField()
    src = models.CharField(max_length=32, default="django")  # django | api | streamlit
    ua = models.TextField(null=True, blank=True)             # user-agent
    user = models.ForeignKey(getattr(settings, "AUTH_USER_MODEL", "auth.User"),
                             null=True, blank=True, on_delete=models.SET_NULL)
    ts = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=["ip","ts"]),
            models.Index(fields=["path"]),
            models.Index(fields=["src","ts"]),
            models.Index(fields=["ts"]),
        ]
```

- 마이그레이션: `python manage.py makemigrations && python manage.py migrate`
    

## 2-2) 전역 로깅 미들웨어(장고/DRF 요청 자동 저장)

```python
# core/middleware/ip_log.py
from django.utils.deprecation import MiddlewareMixin
from core.models.access_log import AccessLog

class IPLogMiddleware(MiddlewareMixin):
    def process_response(self, request, response):
        xff = request.META.get("HTTP_X_FORWARDED_FOR")
        ip = xff.split(",")[0].strip() if xff else request.META.get("REMOTE_ADDR")
        user = getattr(request, "user", None)
        # src는 경로로 구분: /api/면 api, 그 외는 django
        src = "api" if request.path.startswith("/api/") else "django"
        AccessLog.objects.create(
            ip=ip, path=request.path, method=getattr(request, "method", ""),
            status=getattr(response, "status_code", 0), src=src,
            ua=request.META.get("HTTP_USER_AGENT", ""),
            user=(user if getattr(user, "is_authenticated", False) else None),
        )
        return response
```

```python
# settings.py
MIDDLEWARE = [
    # ...
    "core.middleware.ip_log.IPLogMiddleware",
]
```

## 2-3) 스트림릿 전용 트래킹 엔드포인트(브라우저 → 장고로 직접 호출)

```python
# api/dev.py
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from core.models.access_log import AccessLog

@api_view(["GET"])
@permission_classes([AllowAny])  # 내부망 + NGINX Allowlist 전제
def track(request):
    # 브라우저에서 직접 호출되므로 원 IP 확보 가능
    xff = request.META.get("HTTP_X_FORWARDED_FOR")
    ip = xff.split(",")[0].strip() if xff else request.META.get("REMOTE_ADDR")
    ref = request.GET.get("ref", "unknown")
    ua = request.META.get("HTTP_USER_AGENT", "")
    AccessLog.objects.create(
        ip=ip, path=f"ui:{ref}", method="GET", status=200,
        src="streamlit", ua=ua,
        user=(request.user if getattr(request.user, "is_authenticated", False) else None),
    )
    return Response({"ok": True})
```

```python
# config/urls.py
from api import dev
urlpatterns += [
    path("api/dev/track", dev.track),
]
```

---

# 3) Streamlit — 페이지 진입 시 1회 트래킹(JS fetch)

```python
# streamlit_app.py (각 페이지/탭에서 호출)
import streamlit as st
import streamlit.components.v1 as components
from urllib.parse import quote

def track_client(page: str = "home"):
    ref = quote(page)
    components.html(
        f"""
        <script>
          (function(){{
            try {{
              var key = "fmw-tracked-" + new Date().toISOString().slice(0,10) + "-" + "{st.session_state.get('user','dev')}" + "-" + "{'{'}{'}'}" + "{ref}";
              if (!sessionStorage.getItem(key)) {{
                fetch('/api/dev/track?src=streamlit&ref=' + encodeURIComponent('{ref}'),
                      {{ method:'GET', credentials:'include' }}).catch(()=>{});
                sessionStorage.setItem(key, '1');
              }}
            }} catch (e) {{}}
          }})();
        </script>
        """,
        height=0,
    )

# 예시 사용
st.title("FMW")
track_client("overview")  # 오버뷰 탭 진입 시
```

- same-origin 이므로 CORS 불필요.
    
- 세션 스토리지로 **중복 호출 방지**.
    

---

# 4) OPS 대시보드 — 트래픽 화면 추가

## 4-1) 뷰

```python
# ops/views.py
from django.db.models import Count
from django.utils import timezone
from django.shortcuts import render
from core.models.access_log import AccessLog
from datetime import timedelta

def traffic_overview(request):
    days = int(request.GET.get("days", 7))
    since = timezone.now() - timedelta(days=days)
    q = AccessLog.objects.filter(ts__gte=since)

    top_ip = list(q.values("ip").annotate(c=Count("id")).order_by("-c")[:10])
    top_path = list(q.values("path").annotate(c=Count("id")).order_by("-c")[:10])
    top_src = list(q.values("src").annotate(c=Count("id")).order_by("-c"))
    recent = q.order_by("-ts")[:100]

    ctx = {"days": days, "top_ip": top_ip, "top_path": top_path, "top_src": top_src, "recent": recent}
    return render(request, "ops/traffic.html", ctx)
```

## 4-2) URL

```python
# ops/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path("overview", views.overview, name="ops-overview"),
    path("changes", views.changes, name="ops-changes"),
    path("sync", views.sync, name="ops-sync"),
    path("traffic", views.traffic_overview, name="ops-traffic"),  # 신규
]
```

## 4-3) 템플릿(간단 버전)

```html
<!-- templates/ops/traffic.html -->
<h1>트래픽 (최근 {{ days }}일)</h1>

<h2>Top IP</h2>
<ul>
  {% for r in top_ip %}<li>{{ r.ip }} — {{ r.c }}</li>{% endfor %}
</ul>

<h2>Top Path</h2>
<ul>
  {% for r in top_path %}<li>{{ r.path }} — {{ r.c }}</li>{% endfor %}
</ul>

<h2>Source</h2>
<ul>
  {% for r in top_src %}<li>{{ r.src }} — {{ r.c }}</li>{% endfor %}
</ul>

<h2>최근 100건</h2>
<table>
  <tr><th>ts</th><th>ip</th><th>src</th><th>method</th><th>status</th><th>path</th><th>user</th><th>ua</th></tr>
  {% for a in recent %}
    <tr>
      <td>{{ a.ts }}</td><td>{{ a.ip }}</td><td>{{ a.src }}</td>
      <td>{{ a.method }}</td><td>{{ a.status }}</td><td>{{ a.path }}</td>
      <td>{{ a.user }}</td><td>{{ a.ua|default:"" }}</td>
    </tr>
  {% endfor %}
</table>
```

---

# 5) 빠른 점검 순서

1. **Nginx 재적용**: 3개 헤더가 모든 location에 있는지 확인 → `nginx -t && reload`
    
2. **마이그레이션**: `python manage.py makemigrations && migrate`
    
3. **스트림릿 접속**: `/streamlit/` 진입 → 브라우저 개발자도구(Network)에서 `/api/dev/track` 200 확인
    
4. **OPS 확인**: `/ops/traffic?days=7` 접속 → Top IP/Path/Source, 최근 100건 표출 확인
    

---

# 6) 보안/정책 메모

- 내부망 + **IP Allowlist**(Nginx) 전제. 트래킹 엔드포인트는 권한 없이 허용해도 안전(데이터는 단순 접속 로그).
    
- 운영 전환 시, **보존 주기(예: 90일)** + 주기적 **로테이션/아카이브** 권장.
    
- 만약 HSTS가 활성화되어 http→https 강제 승격 이슈가 있다면, 브라우저 HSTS 캐시 제거/도메인 분리 참고.
    

---

원하시면 위 내용을 **07/08/09/11 문서의 최신본으로 반영한 파일**도 만들어 드릴게요. 지금 바로 코드 반영(엔드포인트/OPS 페이지/스트림릿 트래킹) 진행하시겠어요, 선생님?