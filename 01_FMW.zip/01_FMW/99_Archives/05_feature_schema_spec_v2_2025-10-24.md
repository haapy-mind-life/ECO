
# 05. Feature Schema Spec — 최신 (v2, 2025-10-24)

**5줄 요약**
1) 레코드 구조: **model_name → solution → feature_group → feature → dims → mode → value**  
2) `dims`는 **옵션형**이며, `mcc/mnc/region/country/operator/sp_fci` 중 일부만 있어도 됨.  
3) 명칭 혼재(EU, sp white, global, KDDI 등)는 **TaxonomyMap**으로 **표준 이름(canonical)** 로 정규화.  
4) 충돌 시 **가장 구체적인 규칙이 우선**(specific > country > region > global).  
5) CSV/JSON 스펙과 **검증 규칙**, **예시 10개**를 제공.

---

## 1. 필드 정의(간단)

| 필드 | 타입 | 필수 | 예시 | 설명 |
|---|---|---|---|---|
| `model_name` | string | ✔ | `S20` | 디바이스/모델명 |
| `solution` | enum | ✔ | `slsi`, `mtk` | 칩셋/솔루션 |
| `feature_group` | string | ✔ | `IMS`, `RCS`, `allow-list`, `ue-ca` | 기능 그룹(자유 라벨, 표준화 권장) |
| `feature` | string | ✔ | `VoLTE`, `RCS_CHAT`, `CA_B3_B7` | 개별 피처명 |
| `dims` | object | – | `{"mcc":"450","mnc":"05","country":"KR","operator":"KT","sp_fci":"global white"}` | 지역·사업자·SP 등 선택적 차원 |
| `mode` | enum | ✔ | `allow`, `block`, `none` | 동작 모드 |
| `value` | string | ✔ | `true`, `OFF`, `B3+B7`, `json:{...}` | 실제 값(자유 텍스트) |

> **명명 표준**: `sp_fci`는 일관성을 위해 그대로 사용(별칭은 TaxonomyMap에서 정규화).

---

## 2. Dims(선택 필드) 스키마

`dims`는 아래 필드를 **있을 때만** 포함합니다. 없는 필드는 **생략**(또는 DB에 `NULL`).

| 키 | 타입 | 예시 | 비고 |
|---|---|---|---|
| `mcc` | string(3) | `450` | 숫자 3자리 |
| `mnc` | string(2~3) | `05` | 앞 0 유지 |
| `region` | string | `EU` | 표준화 권장 |
| `country` | string(2) | `KR`, `JP` | ISO-3166-1 alpha-2 권장 |
| `operator` | string | `KT`, `KDDI` | 사내 표준 라벨 |
| `sp_fci` | string | `global white`, `sp white` | 서비스 프로파일/FCI 명칭 |

예시:
- `{"sp_fci":"global white"}`  → **가능**
- `{"mcc":"450","mnc":"05"}`  → **가능**
- `{}` (빈 객체) → CSV에선 컬럼 비워두기, JSON에선 `dims` 생략

---

## 3. CSV 스펙(권장)

CSV 헤더(순서 고정):

```
model_name,solution,feature_group,feature,mode,value,mcc,mnc,region,country,operator,sp_fci
```

- `dims` 필드는 **헤더에 분해**해서 배치(없으면 빈 칸).
- 값에 쉼표가 포함되면 CSV 규칙에 따라 **따옴표**로 감싸기.

샘플 레코드 10개:

```
S20,slsi,IMS,VoLTE,allow,true,450,05,,,KT,
S20,mtk,IMS,VoLTE,block,false,450,08,,,KTF,
S20,slsi,ue-ca,CA_B3_B7,allow,B3+B7,,,,,,
S21,slsi,IMS,VoLTE,allow,true,,,,KR,,global white
S21,mtk,RCS,RCS_CHAT,allow,ON,,,,JP,KDDI,sp white
A52,slsi,allow-list,SMS,allow,ON,,,,EU,,global white
A52,mtk,block-list,RCS_FILE,block,OFF,,,,,,global
S23,mtk,IMS,VoLTE,none,NA,,,,,,  # 정책 미정(참고값)
X10,slsi,IMS,VoWiFi,allow,true,450,11,,,SKT,
X10,slsi,IMS,VoLTE,allow,true,,,,KR,,kddi  # 별칭은 TaxonomyMap으로 정규화됨
```

> 주석(`# ...`)은 실제 CSV에 넣지 않습니다. 설명용입니다.

---

## 4. JSON 스펙(대안)

한 레코드 예시(JSONL 또는 배열):

```json
{
  "model_name": "S20",
  "solution": "slsi",
  "feature_group": "IMS",
  "feature": "VoLTE",
  "mode": "allow",
  "value": "true",
  "dims": {"mcc":"450","mnc":"05","operator":"KT"}
}
```

---

## 5. 정규화 규칙(TaxonomyMap)

명칭 혼재를 **표준 이름**으로 바꿉니다. (DB 문서 04 참고)

| 분류(kind) | 예시 별칭 | canonical 예 |
|---|---|---|
| `region` | `eu`, `EU`, `europe` | `EU` |
| `country` | `kor`, `KR`, `korea` | `KR` |
| `operator` | `Ktf`, `KTF`, `ktf` | `KTF` (또는 사내 표준) |
| `sp_fci` | `sp white`, `global white`, `white` | `global white` |
| `feature` | `volte`, `VoLTE` | `VoLTE` |
| `feature_group` | `allowlist`, `allow-list` | `allow-list` |

**권장 절차**
1) 원본 값 → 공백/대소문자 정리  
2) TaxonomyMap 조회 → canonical 교체  
3) 없으면 **새 별칭 후보**로 적재 후 운영자 승인

---

## 6. 충돌 해결(우선순위 규칙)

동일한 `(model_name, solution, feature_group, feature)`에 대해 `dims`/`mode`가 충돌하면 **아래 우선순위**로 결정합니다.

1) **가장 구체적** (mcc+mnc+operator)  
2) mcc+mnc  
3) country  
4) region  
5) **global(무차원)**

같은 우선순위 레벨에서 충돌 시:
- 최신 `sync_time` 우선
- `mode` 우선순위: `block` > `allow` > `none`
- 필요 시 운영자 수동 조정(Ops UI에서 표시)

---

## 7. 검증(Validation) 규칙

- **필수**: `model_name`, `solution`, `feature_group`, `feature`, `mode`, `value`
- `solution` ∈ {`slsi`,`mtk`}
- `mode` ∈ {`allow`,`block`,`none`}
- `mcc`는 숫자 3자리, `mnc`는 2~3자리(문자열 기준, 앞 0 유지)
- `country`는 **대문자 2자리** 권장(ISO-3166-1 alpha-2)
- `dims` 키가 하나도 없으면 → **전체 적용**(global)로 간주
- 레코드 단위 **identity_hash** 생성(04 문서 참고) 후 **업서트**

---

## 8. 사용 예(요청 순서와 해석)

요청 예시(자연어/내부 쿼리):
- “**S20 allow-list slsi VoLTE**에서 KR만 보고 싶음”  
  → `model_name=S20&solution=slsi&feature_group=allow-list&feature=VoLTE&country=KR`
- “`ue-ca` 그룹에서 `CA_B3_B7`이 전세계 허용인지”  
  → `feature_group=ue-ca&feature=CA_B3_B7&mode=allow` + **dims 없음**

---

## 9. 확장 가이드

- **feature_group**: 현재 `allow-list`, `block-list`, `rel-features`, `ue-ca` 등을 사용. 자유 라벨이지만 **TaxonomyMap**으로 표준화 권장.
- **dims**: `province`, `city`, `device_sku` 등 **필드 확장** 가능(옵션형 유지).
- **value**: 단순 텍스트 외에 `json:{...}` 형태 허용(파서 계층에서 JSON 인정).

---

## 10. 변경 이력
- **v2 (2025-10-24)**: 스키마/CSV·JSON 스펙, 정규화/충돌/검증 규칙, 샘플 10건 추가
- **v1**: 초안
