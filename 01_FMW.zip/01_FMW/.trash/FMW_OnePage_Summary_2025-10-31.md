# FMW One‑Page Summary *(for print)*  
**Date:** 2025‑10‑31 • **Owner:** Project Lead (You) • **Audience:** Exec Ops (3)

---

## 1) Why now (Business drivers)
- **Remove “time‑to‑data”**: one trusted place to check features/policy status (SSOT).
- **Speed & trust**: instant read from snapshots; consistent definitions via normalization.
- **Ops efficiency**: daily checks ≤ 30 min while usage (WAU) proves value.

## 2) What we ship (Phase‑1 scope, Windows/On‑prem)
- **Snapshot‑first viewer (Streamlit)**: loads *records.csv* and *runs_summary.json*.
- **API (Django)**  
  - **/api/v1/all**, **/api/v1/{feature_group}** (CSV by default, `?format=json` opt-in)  
  - **/api/dev/sync/run** (trigger ETL), **/api/dev/runs/summary** (overview KPIs)
- **Security**: Nginx IP Allowlist + Apps on **127.0.0.1** (loopback bind).
- **DB**: **Postgres** (server DB; identity hash `UNIQUE` for idempotent upsert).
- **Ops**: services registered (NSSM), batch scripts for deploy/run/reset.

## 3) How it works (Architecture & Pipeline)
**Nginx ▶ Django(API/ETL) & Streamlit(Viewer) + Postgres**
1. **Sync** (extract)
2. **Normalize** (aliases → canonical via name map; includes **MCC/MNC → (region,country,operator)** mapping)
3. **Upsert → `features`**
4. **Write `changes`** (diff C/U/D)
5. **Aggregate `daily_counts`** (1/7/14/30d overview)
6. **Snapshot write** *(atomic rename)* → Viewer loads

## 4) Data model (core tables)
- **features**: current truth (identity_hash `UNIQUE`, canonical fields incl. region/country/operator)
- **changes**: history of C/U/D (before/after, reason, run_id)
- **runs**: each sync execution (start/end, status, totals)
- **daily_counts**: day‑level created/updated/deleted/errors (for Home KPIs)
- **name_map**: taxonomy/alias map incl. **MCC/MNC → geo/operator**

## 5) Success metrics (KPIs/NFRs)
- **Adoption** WAU ≥ **70%**
- **Performance** Home < **1s**, major views P95 < **5s**, /api/v1 P95 < **3s**
- **Reliability** daily sync success ≥ **98%**
- **Operability** daily admin time ≤ **30 min**

## 6) Risks & mitigations
- **SQLite locks** → Use **Postgres** from Day‑1.  
- **Viewer pause during write** → **Atomic snapshot swap**.  
- **Service stops on reboot** → Register **Windows Services** (auto‑restart).  
- **DEV API abuse** → Nginx allowlist; (Phase‑2) API key/SSO.

## 7) Next 30‑60‑90 days (decision/plan)
- **30d (MVP)**: features+runs; `/api/v1/*`, `/api/dev/sync/run`, `/api/dev/runs/summary`; Home/Overview/Dev tabs.
- **60d**: add **changes** UI & export; MCC/MNC map QA; pg_dump nightly backup.
- **90d (Phase‑2)**: SSO/RBAC review; scale plan (Streamlit → API+Web if 200+ users).

---

### Presenter notes (talk‑track, 30–60 sec)
- “**한 장 요약입니다.** 읽기 성능과 안정성을 위해 **스냅샷‑우선**으로 갑니다.  
- 오늘은 **/api/v1, /api/dev** 두 축과 **Postgres** 전환, **Windows 서비스화**를 확정합니다.  
- KPI는 **속도/채택/신뢰성** 세 가지. 30일 MVP로 가치 증명 후 60/90일 로드맵 진행합니다.”