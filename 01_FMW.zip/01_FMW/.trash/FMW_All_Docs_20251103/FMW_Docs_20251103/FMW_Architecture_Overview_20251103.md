# 🏗️ FMW Architecture Overview (2025‑11‑03)
**Phase‑1:** SQLite on Windows · **Phase‑2:** PostgreSQL  
**앱 구조:** Django/**api**(모델·마이그레이션·Admin) · **drf**(REST: v1/dev) · **ops**(운영 대시보드) · **template**(공통 템플릿) · **Streamlit**(조회 전용 UI)

> 본 문서는 날짜 기반 기준선이며, **버전 표기(V1/V2/V3/V4 등)를 사용하지 않습니다.**

---

## 0) 목적 & 범위
- **목적**: 읽기 중심 스냅샷 구조에 보안(Allowlist)·감사(ReqLog)·운영(Ops/Logs)을 더해 **빠르고 투명한 내부 데이터 포털** 제공.
- **범위**: API(v1/dev), 대시보드(ops), Admin, Streamlit, ETL/동기화, DB/ERD, 배포/전환, 감사·모니터링.

---

## 1) 아키텍처 드라이버
- **Snapshot‑First**: 스냅샷/집계 기반으로 홈 < **1s**, 조회 P95 < **5s**
- **Idempotent Upsert**: `identity_hash UNIQUE` 업서트 멱등성 보장
- **Normalize & Enrich**: `name_map` 정규화, `mcc_mnc_map` 보강
- **Defense‑in‑Depth**: **Nginx Allowlist(1차)** + **DRF 권한(2차, dev=IP+Key)**
- **Auditability**: 전 경로 **ReqLog** 수집(`/ops/logs` · `/api/dev/logs`)

---

## 2) C4 — Context / Container / Component
(중략 — 상세는 캔버스 문서와 동일)
