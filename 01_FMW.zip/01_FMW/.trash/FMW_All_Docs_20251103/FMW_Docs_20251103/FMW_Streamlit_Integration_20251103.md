# 📊 FMW Streamlit Integration Guide (2025‑11‑03)
(캔버스 작성본과 동일한 내용. 주요 섹션: 구조, config.toml, DataManager 캐시, WS/서브패스 Nginx, UX 패턴, 감사 통합, DoD)
