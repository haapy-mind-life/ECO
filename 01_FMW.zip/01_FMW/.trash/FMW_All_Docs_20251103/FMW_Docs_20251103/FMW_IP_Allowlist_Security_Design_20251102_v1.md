# 🔐 FMW IP Allowlist Security Design (2025‑11‑02 · v1)
(캔버스 작성본과 동일한 내용. 정책 매트릭스, Nginx/DRF 2단계 방어, 테스트 항목)
