# 🪟 FMW Windows BAT Automation & Orchestration — Architecture Addendum (2025‑11‑02)
(캔버스 작성본과 동일한 내용. 주요 섹션: 운영 원칙, 디렉터리, 포트/바인딩, ReqLog 연계, 시퀀스, 체크리스트)
