# 🐍 FMW Django Implementation Guide (2025‑11‑03)
(캔버스 작성본과 동일한 내용. 주요 섹션: Settings, Models, Admin, DRF, Ops, Mgmt Commands, Tests, Migration/전환 가이드)
