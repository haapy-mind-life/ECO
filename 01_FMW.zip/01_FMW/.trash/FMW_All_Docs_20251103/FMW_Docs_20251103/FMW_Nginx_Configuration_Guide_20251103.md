# 🧰 FMW NGINX Configuration Guide (2025‑11‑03)
(캔버스 작성본과 동일한 내용. 주요 섹션: Allowlist 맵, 서버블록, Streamlit WS, Upstream, real_ip, 로그/감사, DoD)
