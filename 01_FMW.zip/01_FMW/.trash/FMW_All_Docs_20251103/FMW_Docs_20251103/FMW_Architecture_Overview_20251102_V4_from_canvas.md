# 🏗️ FMW Architecture Overview — V4 (2025‑11‑02)
(사용자가 캔버스에서 수정한 최신 V4 문서 전체본)
