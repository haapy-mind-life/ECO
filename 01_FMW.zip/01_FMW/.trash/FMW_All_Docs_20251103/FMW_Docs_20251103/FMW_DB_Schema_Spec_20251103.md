# 🧬 FMW DB Schema Spec (2025‑11‑03)
(캔버스 작성본과 동일한 내용. 주요 섹션: 세로 명세, PG DDL, 검증 SQL, DoD)
