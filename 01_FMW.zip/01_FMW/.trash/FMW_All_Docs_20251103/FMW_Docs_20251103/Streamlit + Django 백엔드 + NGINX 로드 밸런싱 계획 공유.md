### **Streamlit + Django 백엔드 + NGINX 로드 밸런싱 계획 공유**

현재 **Streamlit을 네트워크 배포**하는 과정에서 **NGINX를 이용한 Reverse Proxy**를 도입하는 방향으로 진행 중입니다.  
또한, **백엔드로 Django를 활용할 예정**이므로,  
**로드 밸런싱을 Django 코드 기반으로 처리할 것인지, NGINX에서 설정할 것인지**에 대한 논의를 포함하여 정리합니다.

---

## **1. 현재 진행 상황**
✅ **Streamlit 프로젝트 개발 완료**  
✅ **Streamlit 기본 서버 (`0.0.0.0`)가 회사 보안 정책으로 차단됨**  
✅ **NGINX Reverse Proxy 도입 결정**  
✅ **로드 밸런싱 필요성 검토 중**  
✅ **Django 백엔드 도입 예정 → 로드 밸런싱을 어디서 처리할 것인지 논의 필요**  

---

## **2. 로드 밸런싱 구현 방식 비교**
로드 밸런싱을 적용하는 방법에는 **Django 코드 기반 처리**와 **NGINX 설정 기반 처리**가 있습니다.

### **① Django 기반 로드 밸런싱 (코드로 처리)**
Django에서 API 요청을 받는 백엔드를 운영하면서, **Django 코드 내에서 Streamlit 서버로 요청을 분산**하는 방식입니다.

#### **장점**
✅ 로직을 Django 내에서 자유롭게 제어 가능  
✅ 로드 분배 로직을 커스텀 가능 (예: AI 모델 부하 기반 분배)  
✅ Streamlit 서버 상태 체크 및 동적 분배 가능  

#### **단점**
❌ Django가 로드 밸런서 역할을 해야 하므로 부하 발생 가능  
❌ Django 백엔드가 다운되면 전체 서비스에 영향  

#### **구현 예시 (Django View)**
Django에서 Streamlit 서버로 요청을 보내는 간단한 로드 밸런싱 코드 예제:

```python
import requests
from django.http import JsonResponse
import random

STREAMLIT_SERVERS = [
    "http://127.0.0.1:8501",
    "http://127.0.0.1:8502"
]

def proxy_request(request):
    """랜덤한 Streamlit 서버로 요청을 보내는 로드 밸런싱"""
    server = random.choice(STREAMLIT_SERVERS)
    response = requests.get(f"{server}/", params=request.GET)

    return JsonResponse(response.json())
```
✅ 위와 같은 방식으로 Django가 Streamlit 서버 간의 부하를 분배 가능  
✅ 특정 API 요청에 대해 Django 백엔드가 Streamlit 서버를 선택하여 전달 가능  

---

### **② NGINX 기반 로드 밸런싱 (설정으로 처리)**
Django와 Streamlit을 함께 운영하면서, **NGINX에서 직접 Streamlit 서버로 로드 밸런싱을 설정**하는 방식입니다.

#### **장점**
✅ NGINX는 고성능이므로 부하를 효과적으로 분산 가능  
✅ Django가 직접 요청을 처리하지 않아 부하가 적음  
✅ Streamlit 서버가 추가될 경우, 설정만 변경하면 확장 가능  

#### **단점**
❌ 로드 밸런싱 로직을 커스텀하기 어려움 (정적 분배)  
❌ Streamlit 서버 상태를 실시간으로 체크하는 기능이 부족할 수 있음  

#### **NGINX 설정 예시 (로드 밸런싱 적용)**
파일: `/etc/nginx/sites-available/streamlit`
```nginx
upstream streamlit_servers {
    server 127.0.0.1:8501;
    server 127.0.0.1:8502;
}

server {
    listen 80;
    server_name streamlit.company.com;

    location / {
        proxy_pass http://streamlit_servers;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
✅ 위 설정을 적용하면 **NGINX가 자동으로 부하를 Streamlit 서버에 분산**  
✅ 필요하면 `ip_hash;`, `least_conn;` 등으로 로드 밸런싱 방식 조정 가능  

설정 적용:
```bash
sudo nginx -t  # 설정 확인
sudo systemctl restart nginx
```

---

## **3. Django vs. NGINX 기반 로드 밸런싱 결정**
| 방법 | 장점 | 단점 | 추천 용도 |
|------|------|------|------|
| **Django 코드 기반** | 로드 분배 로직을 직접 제어 가능 | Django 서버 부하 증가 가능 | Streamlit 요청을 AI/ML 기반으로 동적 분배할 때 |
| **NGINX 설정 기반** | 고성능, 간편한 설정 | 커스텀 로직 적용 어려움 | 단순한 로드 밸런싱이 필요한 경우 |

🚀 **현재 상황에서 추천하는 방법:**  
✅ 기본적으로 **NGINX 로드 밸런싱을 적용**하고,  
✅ 추가적인 로직이 필요하면 Django에서 일부 요청을 컨트롤하는 방식으로 보완  

---

## **4. 최종 로드맵**
✅ **1차 목표:** NGINX Reverse Proxy + 기본 로드 밸런싱 설정 적용  
✅ **2차 목표:** Streamlit 서버 추가 및 성능 테스트  
✅ **3차 목표:** 필요 시 Django에서 동적 로드 밸런싱 코드 추가  

📌 **현재 진행 중인 작업:**
- NGINX 로드 밸런싱 설정 적용 및 테스트
- Streamlit 서버 추가 및 분산 처리 확인

📌 **다음 회의에서 논의할 내용:**
- Django 코드 기반 로드 밸런싱 필요성 여부
- NGINX 로드 밸런싱 방식 (round-robin, least_conn 등) 최적화
- 배포 후 성능 테스트 및 개선점 도출

🚀 **빠른 적용을 위해 NGINX 로드 밸런싱을 우선 적용하며, Django를 활용한 동적 로드 밸런싱은 추가 논의 후 결정 예정입니다.**  

의견이나 추가 요청 사항이 있으면 공유 부탁드립니다!  

#Streamlit #Django #NGINX #로드밸런싱 #ReverseProxy #보안설정 #네트워크배포