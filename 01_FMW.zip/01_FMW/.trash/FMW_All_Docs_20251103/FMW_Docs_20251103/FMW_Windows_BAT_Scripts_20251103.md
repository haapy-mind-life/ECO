# 🪟 FMW Windows BAT Scripts (2025‑11‑03)
(캔버스 작성본과 동일한 내용. 주요 섹션: 루트 스크립트, sync.bat, run_all.py, 스케줄러, 품질 수칙, DoD)
