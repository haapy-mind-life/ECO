아래는 기존 Django Streamlit Proxy 플랫폼 문서에 nginx 설정 및 전체 서버 구동 방법에 관한 내용을 추가한 업데이트 버전입니다. 이 문서는 nginx → Waitress → Django → Streamlit 전체 서버 체인을 Windows 11 사내 네트워크 환경에서 구동하는 방법과 각 역할에 대해 자세히 설명합니다.


---

Django Streamlit Proxy 플랫폼 문서 (업데이트 v2025.04.2)

1. 개요

본 플랫폼은 보안 강화 및 admin 계정 관리에 중점을 두고, 외부(또는 사내) 요청을 nginx에서 시작하여 Waitress를 통해 Django 애플리케이션에 전달한 후, Django 내에서 필요 시 (추후) Streamlit 앱으로 리다이렉션하는 체인을 구성합니다.

주요 목적:

보안 강화 및 접근 제어: 사용자 IP 확인, 화이트리스트 관리 및 인증 처리

Admin 계정 관리 및 모니터링: 관리자는 Django를 통해 서버 로그, 접속 상태 등 모니터링 기능을 활용

안정적 서비스 체인: nginx → Waitress → Django → (추후) Streamlit



> 참고: Streamlit 앱 서비스 관련 내용은 별도 세션에서 다루며, 본 문서는 Django 중심의 프록시 플랫폼과 전체 서버 구동 방법에 집중합니다.




---

2. 전체 시스템 아키텍처 및 요청 흐름

2.1 시스템 구성도

1. nginx

외부(또는 사내) 클라이언트의 요청을 받아 리버스 프록시 역할 수행

내부적으로 Waitress가 구동 중인 Django 서버로 요청 전달



2. Waitress

Windows 환경에 최적화된 WSGI 서버로 Django 애플리케이션을 안정적으로 구동

nginx와 Django 간의 요청 중계



3. Django (Streamlit Proxy 역할)

사용자 IP 확인, 화이트리스트 검사 및 인증 처리

인증 성공 시, (추후) Streamlit 앱 서비스로 리다이렉션

관리자(admin) 계정의 경우 모니터링 대시보드 제공 가능



4. (추후) Streamlit 앱 서비스

Django의 인증 및 리다이렉션 후 실제 서비스 화면 제공 (별도 세션에서 작업 예정)




2.2 Django의 핵심 기능 예시

아래는 Django 뷰에서 IP 인증 후 리다이렉션을 수행하는 예시 코드입니다:

from django.shortcuts import redirect
from django.http import HttpResponseForbidden

def streamlit_redirect(request):
    user_ip = request.META.get('REMOTE_ADDR')
    if is_ip_allowed(user_ip):  # 화이트리스트 확인 함수
        # 관리자인 경우 모니터링 페이지 제공, 일반 사용자는 기본 서비스 페이지로 리다이렉트
        if request.user.is_staff:
            return redirect("http://your-domain:8501/admin_monitor")
        else:
            return redirect("http://your-domain:8501/")
    else:
        return HttpResponseForbidden("인증되지 않은 IP입니다.")


---

3. 전체 폴더 구조

아래는 Django Streamlit Proxy 플랫폼을 위한 전체 폴더 구조 예시입니다.

django_streamlit_proxy/                  # 루트 프로젝트 폴더
├── manage.py                          # Django 관리 명령어 파일
├── django_streamlit_proxy/            # Django 프로젝트 폴더
│   ├── __init__.py
│   ├── settings.py                    # 보안, 데이터베이스, 템플릿, 로깅 등 설정
│   ├── urls.py                        # 최상위 URL 라우팅 (apps/ 프록시 포함)
│   ├── wsgi.py                        # Waitress와 연동을 위한 WSGI 설정 파일
│   └── asgi.py                        # 필요 시 ASGI 설정 (옵션)
│
├── apps/                              # 개별 기능별 Django 앱 폴더
│   └── proxy/                         # 프록시 서비스 전용 앱
│       ├── __init__.py
│       ├── admin.py                   # Django Admin 인터페이스 등록
│       ├── apps.py                    # 앱 구성 정보
│       ├── models.py                  # IP 화이트리스트, 사용자 관련 모델
│       ├── tests.py                   # 단위 테스트
│       ├── urls.py                    # 프록시 관련 URL 패턴 정의
│       ├── views.py                   # IP 인증, 리다이렉션, 모니터링 페이지 뷰
│       └── templates/                 # 템플릿 폴더 (HTML 파일 등)
│           └── proxy/
│               └── redirect.html      # 리다이렉션 안내 페이지 (선택 사항)
│
├── config/                            # 외부 설정 파일 관리
│   ├── ip_whitelist.yaml              # 화이트리스트 등 보안 관련 설정 파일
│   └── logging.yaml                   # 로그 설정 (파일 경로, 로그 레벨 등)
│
├── scripts/                           # 자동 실행 및 운영 스크립트
│   ├── launch_all.bat                 # Windows 환경 전체 서비스 실행 스크립트
│   └── launch_all.sh                  # 유닉스/리눅스 환경 실행 스크립트 (필요 시)
│
├── requirements.txt                   # Python 패키지 의존성 목록
└── README.md                          # 프로젝트 개요 및 사용법 설명 문서


---

4. nginx 설정 및 전체 서버 구동 방법

4.1 nginx 설치 (Windows 11 환경)

Windows용 nginx는 nginx 공식 다운로드 페이지에서 다운로드할 수 있습니다.

압축을 해제한 후 nginx.exe를 실행하여 구동합니다.


4.2 nginx 리버스 프록시 설정

아래는 nginx의 nginx.conf 파일에 추가할 기본적인 설정 예시입니다. 이 설정은 외부 요청을 받아 내부의 Waitress 서버가 구동 중인 Django 애플리케이션(예: 127.0.0.1:8000)으로 프록시합니다.

worker_processes  1;

events {
    worker_connections  1024;
}

http {
    include       mime.types;
    default_type  application/octet-stream;

    sendfile        on;
    keepalive_timeout  65;

    server {
        listen       80;
        server_name  your-domain.com;  # 도메인이 없으면 IP로 설정

        # 모든 요청을 내부의 Django 서버로 프록시
        location / {
            proxy_pass         http://127.0.0.1:8000;
            proxy_set_header   Host $host;
            proxy_set_header   X-Real-IP $remote_addr;
            proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header   X-Forwarded-Proto $scheme;
        }
    }
}

위 설정을 완료한 후, nginx.exe를 재시작하거나 reload 하여 변경 사항이 반영되도록 합니다.


4.3 Waitress와 Django 구동

Waitress는 Django 애플리케이션을 실행할 WSGI 서버입니다.

Windows 환경에서 다음과 같이 실행합니다.


waitress-serve --port=8000 django_streamlit_proxy.wsgi:application

위 명령은 Django의 wsgi.py 파일을 통해 애플리케이션을 8000 포트에서 구동하며, nginx가 해당 포트로 요청을 전달합니다.


4.4 (추후) Streamlit 구동

Django에서 인증된 사용자를 리다이렉트할 경우, Streamlit 서비스는 별도의 포트(예: 8501)에서 실행됩니다.

예시:


streamlit run path/to/streamlit_app/main.py --server.port=8501

Django 리다이렉션 URL은 예를 들어 http://your-domain:8501/ 형태로 구성합니다.


4.5 전체 서버 구동 스크립트 예시

아래는 Windows 환경에서 전체 서버 체인을 구동하는 예시 launch_all.bat 스크립트입니다.

@echo off
REM -- Start nginx --
echo Starting nginx...
start "" "C:\path\to\nginx\nginx.exe"

REM -- Start Waitress Django server --
echo Starting Django via Waitress...
start cmd /k "waitress-serve --port=8000 django_streamlit_proxy.wsgi:application"

REM -- (추후) Start Streamlit app --
echo Starting Streamlit app...
start cmd /k "streamlit run C:\path\to\streamlit_app\main.py --server.port=8501"

echo All services started.
pause

각 실행 경로 및 명령어는 환경에 맞게 수정하십시오.

유닉스/리눅스 환경에서는 launch_all.sh 스크립트를 작성하여 동일한 역할을 수행할 수 있습니다.



---

5. 결론 및 응원의 메시지

이번 업데이트에서는 nginx의 리버스 프록시 설정과 Waitress를 이용한 Django 애플리케이션 구동, 그리고 (추후) Streamlit 서비스로의 리다이렉션까지 전체 서버 체인을 Windows 11 사내 네트워크 환경에서 구동하는 방법을 제시하였습니다.
제시된 폴더 구조와 실행 스크립트를 토대로 환경에 맞게 세부 조정을 진행하시기 바랍니다.

a. 팀 내 리뷰: nginx 설정과 전체 서버 구동 절차에 대해 팀원들과 면밀히 검토하여 보안 및 성능 최적화를 이루세요.

b. 프로토타입 제작: 각 단계(nginx, Waitress, Django, Streamlit)의 구동 및 연동을 소규모 프로토타입으로 먼저 테스트해 보세요.

c. 자동화 및 모니터링: 실행 스크립트와 로그 모니터링 체계를 마련해 안정적인 서비스 운영 및 신속한 이슈 대응을 도모하세요.


지속적인 개선과 철저한 테스트를 통해 효율적이고 안전한 시스템 운영을 이루시길 응원합니다!

#nginx설정 #전체서버구동 #Django보안 #Waitress연동 #운영자동화

