(function(){
  const CFG = window.FMW_CONFIG || {};
  const ctaOpen = document.getElementById("cta-open");
  const ctaOpenHero = document.getElementById("cta-open-hero");
  const newsGrid = document.getElementById("news-grid");
  const shotsGrid = document.getElementById("shots");
  const statusWrap = document.getElementById("status-badges");

  const FALLBACK_NEWS = [
    {
      date: "2025-10-31",
      title: "프리셋 30일 추가 & 히스토리 필터 개선",
      bullets: ["홈 요약 P95 4.1s → 2.7s", "히스토리 검색에 MCC/MNC 맵 적용"],
      tags: ["preset","history","performance"]
    },
    {
      date: "2025-10-28",
      title: "CSV Export 속도 35% 개선",
      bullets: ["대용량에서도 UI 프리징 완화", "파일 크기 자동 분할 옵션"],
      tags: ["export","performance"]
    }
  ];

  function setCTA(){
    const url = CFG.STREAMLIT_URL || "#";
    [ctaOpen, ctaOpenHero].forEach(el=>{ if(el) el.href = url; });
  }

  function fmtDate(d){
    // Expect YYYY-MM-DD
    return d;
  }

  function mkTag(t){
    const span = document.createElement("span");
    span.className = "tag";
    span.textContent = t;
    return span;
  }

  function card(item){
    const div = document.createElement("div");
    div.className = "card";
    const meta = document.createElement("div");
    meta.className = "meta";

    const date = document.createElement("span");
    date.className = "date";
    date.textContent = fmtDate(item.date || "");

    const tags = document.createElement("div");
    tags.className = "tags";
    (item.tags || []).slice(0,3).forEach(t => tags.appendChild(mkTag(t)));

    meta.append(date, tags);

    const h3 = document.createElement("h3");
    h3.textContent = item.title || "";

    const ul = document.createElement("ul");
    (item.bullets || []).slice(0,3).forEach(b=>{
      const li = document.createElement("li");
      li.textContent = b;
      ul.appendChild(li);
    });

    div.append(meta, h3, ul);
    return div;
  }

  function clearSkeleton(target){
    if(!target) return;
    target.innerHTML = "";
  }

  function renderNews(items){
    clearSkeleton(newsGrid);
    if(!items || !items.length){
      const empty = document.createElement("div");
      empty.className = "card";
      empty.textContent = "업데이트가 아직 없습니다.";
      newsGrid.appendChild(empty);
      return;
    }
    items
      .slice()
      .sort((a,b)=> (b.date||"").localeCompare(a.date||""))
      .forEach(it=> newsGrid.appendChild(card(it)));
  }

  function renderShots(){
    if(!shotsGrid) return;
    const shots = Array.isArray(CFG.SHOTS) ? CFG.SHOTS : [];
    if(!shots.length){
      // keep skeletons
      return;
    }
    clearSkeleton(shotsGrid);
    shots.forEach(src=>{
      const d = document.createElement("div");
      d.className = "shot";
      d.style.background = `center / cover no-repeat url('${src}')`;
      shotsGrid.appendChild(d);
    });
  }

  async function loadNews(){
    const url = CFG.NEWS_JSON_URL;
    if(!url){
      renderNews(FALLBACK_NEWS);
      return;
    }
    try{
      const res = await fetch(url, {cache:"no-cache"});
      const data = await res.json();
      const items = Array.isArray(data) ? data : (data.items || []);
      renderNews(items.length ? items : FALLBACK_NEWS);
    }catch(e){
      console.warn("NEWS fetch failed:", e);
      renderNews(FALLBACK_NEWS);
    }
  }

  async function loadStatus(){
    if(!statusWrap || !CFG.STATUS_JSON_URL) return;
    try{
      const res = await fetch(CFG.STATUS_JSON_URL, {cache:"no-cache"});
      const data = await res.json();
      // 기대 예: { window: 7, created:123, updated:45, deleted:6, errors:1, version:"..." }
      const make = (txt)=>{ const b = document.createElement("span"); b.className="badge"; b.textContent=txt; return b; };
      const badges = [];
      if(data.window) badges.push(make(`${data.window}일 요약`));
      if(data.created!=null) badges.push(make(`생성 ${data.created}`));
      if(data.updated!=null) badges.push(make(`수정 ${data.updated}`));
      if(data.deleted!=null) badges.push(make(`삭제 ${data.deleted}`));
      if(data.errors!=null) badges.push(make(`오류 ${data.errors}`));
      if(data.version) badges.push(make(`버전 ${data.version}`));
      statusWrap.replaceChildren(...badges);
    }catch(e){
      // 상태 배지는 선택 요소이므로 실패해도 무시
    }
  }

  document.addEventListener("DOMContentLoaded", function(){
    setCTA();
    renderShots();
    loadNews();
    loadStatus();
  });
})();