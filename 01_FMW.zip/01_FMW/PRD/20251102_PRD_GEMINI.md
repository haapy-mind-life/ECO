🧭 FMW Product Requirement Document (PRD)
| 항목 | 값 |
|---|---|
| 문서명 | FMW 제품 요구사항 문서 (PRD) |
| 문서 ID | PRD-FMW-20251102 |
| 버전 | 1.3.0 ✨ |
| 상태 | Baselined (PoC 완료 → 1차 롤아웃, 전문가 리뷰용) ✅ |
| 기준일 | 2025-11-02 |
| 작성자 | @happy.mind.life79 |
| 검토/승인자 | 아키텍트 / 보안 / 운영 / 관리자(3명) |
0. 📘 문서 목적
본 문서는 FMW 시스템의 PoC 완료 및 1차 롤아웃(내부 팀 20명) 기준으로, 비즈니스·아키텍처·운영·보안·사용자 관점을 통합한 공식 기준선입니다. 모든 산출물은 날짜 기반 버전(YYYYMMDD) 정책으로 관리합니다.
1. 🎯 비즈니스 드라이버 요약
1.1 핵심 문제
조직 내 정책/피처 데이터의 파편화로 인한 **탐색 비용(Time-to-Data)**이 과도합니다. \rightarrow 팀원은 정보를 얻기 위해 매번 개발자에게 문의해야 하고, 이는 생산성을 저하시킵니다. 🧭⏱️
1.2 비즈니스 목표
| 구분 | 목표 | 성과지표(KPI) |
|---|---|---|
| 속도 ⚡ | 탐색 시간 ‘분→초’ 단축 | Home < 1s / 조회 P95 < 5s |
| 신뢰 🔒 | 단일 진실 공급원(SSOT) | 동기화 성공률 \ge 98% |
| 효율 🛠️ | 운영 부담 최소화 | 관리자 점검 \le 30분/일 |
| 채택 📈 | 내부 사용자 활성 | WAU \ge 70% |
1.3 핵심 가치
 * 정량적 ROI: 팀원 20명 \times N분 절감 \rightarrow 생산성 향상
 * 정성적 리스크 감소: 잘못된 정보/운영 리스크 제거, 감사 추적 기반 확보 💡
2. 🧩 제품 개요 (Overview)
미션: 내부 정책/피처 데이터를 빠르고 안정적으로 제공해 ‘탐색 비용’을 제거합니다.
핵심 솔루션 전략:
 * Snapshot First (스냅샷 우선 조회) 📸
 * Dual-Layer Security (Nginx Allowlist + Loopback) 🛡️
 * Idempotency & Normalization (identity_hash, name_map) 🧱
 * Enrich Before Upsert (MCC/MNC \rightarrow 지역/국가/사업자 보강) 🌍
2.1 데이터 흐름
Sync \rightarrow Normalize/Enrich \rightarrow Upsert(features) \rightarrow Write changes \rightarrow Aggregate(daily_counts) \rightarrow Snapshot \rightarrow UI 🔄
3. 👥 사용자 페르소나 & JTBD
| 구분 | 사용자 | 핵심 JTBD | 요구 |
|---|---|---|---|
| 1차 사용자 | 내부 팀원 20명 | “내가 개발 중인 피처의 현재 상태를 즉시 보고 싶다.” | 속도, 신뢰, 간결한 UI |
| 2차 사용자 | 그룹 사용자 | “보안 검증된 공식 툴에서 내 역할에 맞는 데이터만 보고 싶다.” | SSO/RBAC, 안정성 |
| 관리자(3명) | 운영/고과권자 | “최소 리소스로 WAU 70%를 유지하고 싶다.” | 운영 자동화, 안정성 |
4. 📦 범위 (Scope)
4.1 포함
 * 스냅샷 기반 읽기 전용 조회(UI: Streamlit)
 * CSV/JSON API (/api/v1)
 * 운영 요약 대시보드, 자동화 스크립트(run_all.py, Sync.bat)
 * IP Allowlist / 루프백 기반 보안 적용 ✅
4.2 제외
 * UI CUD 기능
 * SSO/RBAC (Phase 2)
 * 외부망 공개, 멀티테넌시 🚫
5. 🏗️ 아키텍처 드라이버
5.1 핵심 원칙
| 원칙 | 목적 | 설명 |
|---|---|---|
| Snapshot First 📸 | 성능/복원력 | 사전 생성된 records.csv 기반 로딩 |
| Dual-Layer Security 🛡️ | 보안 | Nginx Allowlist + Loopback binding |
| Idempotency & Normalization 🧱 | 무결성 | identity_hash UNIQUE, name_map 정규화 |
| Automated Operations 🔁 | 운영성 | NSSM 기반 Windows 서비스 등록 |
| Phased Rollout 🪜 | 전략 | ①가치 증명 \rightarrow ②보안·확장 증명 |
5.2 C4 구조 요약 (Phase 1)
 * Gateway (Nginx): 127.0.0.1:8000/8501로 라우팅, IP Allowlist
 * Backend (Django): /api/v1, /api/dev 루프백 전용
 * Viewer (Streamlit): Snapshot 기반 UI
 * Database: Postgres (SQLite 금지, 동시 20명 대응)
 * OS: Windows Server (PoC/1차 롤아웃 공통) 🖥️
6. 💾 데이터 모델 (ERD 요약)
| 테이블 | 역할 |
|---|---|
| features | 기능 상태 원장 (identity_hash UNIQUE) |
| changes | C/U/D 이력 (감사/비교용) |
| runs | Sync 실행 로그 (집계/모니터링) |
| daily_counts | 일별 집계 (UI KPI용) |
| name_map | 비표준명 \leftrightarrow 표준명 매핑 |
| mcc_mnc_map | MCC/MNC \leftrightarrow region/country/operator 🗺️ |
7. 🔌 API 설계
본 기준(1.3.0): 모든 API는 DRF 출력.
/api/v1/features JSON 기본, /api/v1/features/download CSV 스트리밍로 확정. ✅
7.1 /api/v1 (읽기 전용)
 * GET /api/v1/features : 전체 스냅샷 (JSON 기본)
 * GET /api/v1/features/{feature_group} : 그룹별 필터
 * GET /api/v1/features/download : 대용량 스트리밍 (CSV) 🧾
7.2 /api/dev (내부 운영)
 * POST /api/dev/sync/run : ETL 트리거
 * GET /api/dev/runs/summary : 집계 오버뷰
 * GET /api/dev/changes : 변경 이력
 * 정책: /api/dev/*은 내부망 + API Key + 관리자 IP만 허용. 🔒
8. 🧠 비기능 요구사항 (NFRs)
| 구분 | 항목 | 목표 | 전략 |
|---|---|---|---|
| 성능 ⚡ | Home < 1s, 조회 P95 < 5s | 사용자 체감 속도 개선 | Snapshot + daily_counts |
| 안정성 🤝 | 동기화 성공률 \ge 98% | 신뢰 유지 | ETL 모니터링 자동화 |
| 보안 🛡️ | 비허용 IP 0% | 내부 경계 강화 | Nginx Allowlist + Loopback |
| 운영성 🧰 | 점검 \le 30분/일 | 효율성 | NSSM, deploy.bat |
| 복원력 ♻️ | 장애 시 마지막 스냅샷 제공 | 지속 서비스 | Atomic snapshot 교체 |
9. ⚠️ 리스크 및 대응 전략
| 리스크 | 설명 | 대응 |
|---|---|---|
| 서비스 중단 | 서버 재부팅 시 프로세스 종료 | NSSM 서비스 등록 |
| DB 잠금 | SQLite 동시 접근 | Postgres 전환 |
| 스냅샷 충돌 | 쓰기/읽기 동시 접근 | 임시 파일 \rightarrow 원자적 rename |
| 데이터 유실 | 장애 시 DB 손실 위험 | pg_dump + 작업 스케줄러 자동 백업 |
| 확장 실패 | Streamlit 메모리 한계 | Phase 2: API + Web 구조 전환 |
| 보안 불가 | 보안팀 SSO/RBAC 요구 미충족 | Phase 2에서 반영 🔧 |
10. 🗺️ 로드맵
| 단계 | 목표 | 주요 조치 |
|---|---|---|
| Phase 1 (현재) | 가치 증명 (Prove Value) | 20명 대상 운영, KPI 달성(WAU 70%, 안정성) |
| Phase 2 (예정) | 보안·규모 증명 (Prove Scale) | SSO/RBAC, HTTPS, API+Web 구조 전환 🚀 |
11. 📑 부록 — 버전 관리 정책 요약
 * 문서 버전 규칙: MAJOR.MINOR.PATCH
 * 상태 워크플로: Draft \rightarrow In Review \rightarrow Baseline \rightarrow Amended \rightarrow Deprecated
 * 저장소 권장 구조: /docs/prd/PRD-FMW-YYYYMMDD.md
 * 릴리스 태그: prd-v1.3.0
 * 검증 체크리스트:
   * [x] 버전·상태 최신
   * [x] 범위/요구사항/AC 명확
   * [x] API·보안·운영 일치
   * [x] KPI·NFR 정의
   * [x] CHANGELOG 반영 📝
12. 🧩 변경 이력
| 일자 | 버전 | 변경 내용 | 작성자 |
|---|---|---|---|
| 2025-10-07 | 1.0.0 | 초기 PRD 베이스라인 | 선생님 |
| 2025-10-31 | 1.2.0 | GPT/GEMINI 통합, PoC 완료 반영 | GPT |
| 2025-11-02 | 1.3.0 | 모든 API DRF 출력, /api/v1/features JSON 기본, /download CSV 스트리밍 확정 | GPT-5 |
🔖 요약 해시태그
#FMW #PRD #DRF #SnapshotFirst #DualLayerSecurity #Idempotency #WindowsService #Postgres #KPI #RolloutPhase1 #Baseline20251102
