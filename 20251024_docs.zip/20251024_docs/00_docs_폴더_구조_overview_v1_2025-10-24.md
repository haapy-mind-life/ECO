# 00. 전체 문서 폴더 구조 — 최신 업데이트 (v1, 2025-10-24)

**목적:** 팀원 누구나 빠르게 문서를 찾고, 최신 산출물(코드/설정/배포 스크립트)까지 한 눈에 연결할 수 있도록 폴더 구조와 링크를 정리합니다.

---

## A. 폴더 트리(권장)
```
docs/
 ├─ 00_overview/               # 문서 인덱스(이 파일)
 ├─ 01_prd/                    # 제품/프로젝트 요구사항(PRD)
 ├─ 02_arch_drivers/           # 아키텍처 드라이버
 ├─ 03_c4_overview/            # C4 다이어그램/아키텍처 개요
 ├─ 04_db/                     # 데이터베이스 설계/ERD/기초
 ├─ 05_feature_schema/         # Feature/Dim 스키마 스펙
 ├─ 06_api/                    # OpenAPI/엔드포인트 명세
 ├─ 07_streamlit/              # UX/화면/데이터 매니저 가이드
 ├─ 08_django/                 # Django 구조&운영 가이드, 전체 번들
 ├─ 09_nginx/                  # NGINX 설정/문서 (Windows/Linux)
 └─ 10_automation_windows/     # Windows 자동화(BAT + run_all.py)
```

> 실제 파일은 산출물 특성상 문서 루트 혹은 `sandbox` 경로에 위치합니다. 아래 **링크 모음**을 통해 직접 접근하세요.

---

## B. 링크 모음(최신 산출물)

### 01. PRD
- 최신 PRD(v1, 2025-10-22): [fmw_프로젝트_prd_v_1_2025_10_22.md](sandbox:/mnt/data/fmw_프로젝트_prd_v_1_2025_10_22.md)
- 작업본 PRD(v1, undated): [fmw_프로젝트_prd_v_1.md](sandbox:/mnt/data/fmw_프로젝트_prd_v_1.md)
- 과거 PRD(250926): [250926_FMW-PRD.md](sandbox:/mnt/data/250926_FMW-PRD.md)
- 과거 PRD(2025-09-22): [2025-09-22-FMW PRD.md](sandbox:/mnt/data/2025-09-22-FMW PRD.md)

### 02. 아키텍처 드라이버 / 비즈니스 드라이버
- 아키텍처 드라이버 v1: [02_아키텍처_드라이버_v_1.md](sandbox:/mnt/data/02_아키텍처_드라이버_v_1.md)
- 비즈니스 드라이버 v1: [fmw_비즈니스_드라이버_v_1.md](sandbox:/mnt/data/fmw_비즈니스_드라이버_v_1.md)

### 03. Architecture Overview (C4)
- C4 개요 v1: [03_architecture_overview_c_4_v_1.md](sandbox:/mnt/data/03_architecture_overview_c_4_v_1.md)

### 04. 데이터베이스
- DB ERD v1 (2025-10-22): [fmw_db_schema_erd_v_1_2025_10_22.md](sandbox:/mnt/data/fmw_db_schema_erd_v_1_2025_10_22.md)
- 최소 DB 설계(초안): [FMW 최소 DB 설계 1.md](sandbox:/mnt/data/FMW 최소 DB 설계 1.md)
- DB 기초 개념 정리: [DB 기초 개념 정리 1.md](sandbox:/mnt/data/DB 기초 개념 정리 1.md)

### 05. Feature Schema (스펙)
- (제안) `05_feature_schema_spec_v1.md` — **필드 구조**: `model_name, solution, feature_group, feature, dims(mcc/mnc/region/country/operator/sp_fci), mode, value`  
  → 필요 시 생성 요청해 주세요. 대화 내용 기반으로 바로 작성 가능합니다.

### 06. API
- OpenAPI(DRF 스켈레톤) v1: [06_open_api_스켈레톤_drf_기반_v_1.yaml](sandbox:/mnt/data/06_open_api_스켈레톤_drf_기반_v_1.yaml)
- 주요 엔드포인트 요약:  
  - `GET /api/v1/all`, `GET /api/v1/{feature_group}` (CSV 기본, JSON 옵션)  
  - `POST /api/dev/sync`, `GET /api/dev/runs/summary?days=N`

### 07. Streamlit
- 홈/오버뷰/히스토리/필터 뷰 + **개발자용 수동 동기화** UI (문서/코드는 Django 번들 및 대화 스니펫 참조)
- (제안) `07_streamlit_ux_가이드_v1.md` 문서화 요청 시 생성

### 08. Django
- 08. Django 구조 & 운영 가이드 v1: (파일 없음 — TODO)
- Django 전체 번들 ZIP: (파일 없음 — TODO)

### 09. NGINX
- NGINX 패키지 ZIP(Windows 우선): (파일 없음 — TODO)
- 최소 NGINX 단일 파일(conf): (파일 없음 — TODO)

### 10. Windows 자동화
- Windows 자동화 패키지 ZIP: (파일 없음 — TODO)

### (부록) YAML Seeds
- yaml seeds ZIP: (파일 없음 — TODO)

---

## C. 버전 규칙
- 파일명에 `v{번호}_YYYY-MM-DD`를 권장. 예: `08_django_..._v1_2025-10-24.md`
- 달라붙는 산출물(ZIP/CONF)은 **날짜 기준**으로 최신 판별

---

## D. 오늘 변경 사항(요약)
- `08 Django 가이드` 신규 작성 및 링크 추가
- `09 NGINX 패키지(Windows/Linux)` + **최소 conf** 추가
- `10 Windows 자동화(BAT + run_all.py)` 패키지 추가
- `yaml seeds` ZIP 추가
- 전체 폴더 가이드(이 문서) 최신화

---

## E. 다음 액션(제안)
1) **05 Feature Schema** 문서 정식 작성(필드/유효성/우선순위/충돌해결 규칙 포함)  
2) Streamlit UX 문서(07) 및 화면 캡처 갱신  
3) PRD 최신판(v2) 생성 후 01 폴더에 기준점 확정
