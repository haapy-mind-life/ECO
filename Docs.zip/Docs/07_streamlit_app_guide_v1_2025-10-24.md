---
title: 07 — Streamlit 앱 가이드 (FMW)
version: v1.0
updated: 2025-10-24
owner: 선생님
audience: 개발팀 20명(파일럿), 운영 3인
links:
  - 01_fmw_비즈니스_드라이버_v1_2025-10-24.md
  - 02_아키텍처_드라이버_v1_2025-10-24.md
  - 03_architecture_overview_c4_v1_2025-10-24.md
  - 04_fmw_prd_v1_2025-10-24.md
  - 05_feature_record_spec_v1_2025-10-24.md
  - 06_open_api_overview_v1_2025-10-24.md
  - fmw_streamlit_cloud_demo_v1_2.py
---

# 1) 목적·범위 (쉬운 버전)
- 이 문서는 **Streamlit 앱 설치/운영/UX**를 **한 눈에** 설명합니다.
- 대상: 우리팀 **개발자 20명**(일반 사용자) + **운영 3인**.

---

# 2) 앱 한장 요약
- **앱명**: `fmw`  
- **주요 페이지**(상단 메뉴/사이드바):
  1) **홈 오버뷰** — 현재 레코드, 오늘 변경, 스냅샷, 미니 추세
  2) **히스토리 관리** — 전일/`N`일 전 대비 **CRUD**(신규/업데이트/삭제) + 검색/다운로드
  3) **피처 상세** — 선택 모델/그룹/피처 **분포** + 상세 테이블
  4) **데이터 탐색** — Mode/Country/Operator 필터 + Top10
  5) **추세(라인차트)** — 최근 `N`일 **created/updated/deleted** 추세
  6) **타임라인(피처/모델)** — 선택 기준의 일자별 변경 로그(접이식 상세)
  7) **개발자 모드(임시)** — 동기화 시간 설정·**수동 동기화 버튼**

- **사이드바 필터**: 모델, 피처 그룹, `N`일 전 비교 슬라이더, 추세 기간 슬라이더

---

# 3) 데이터 흐름 (DataManager)
1. 사용자가 앱 접속 → **캐시 신선도** 확인
2. 캐시가 오래됐거나 첫 접속이면 `GET /api/v1/all` **CSV 벌크** 수신
3. **.cache/fmw_all.csv** 저장 + **.cache/daily/YYYY-MM-DD.csv** **스냅샷**
4. 화면은 캐시/스냅샷 기반으로 렌더  
   → 서버 과부하 없이 빠른 UX

기본 스케줄 권장: **KST 06:00** (운영자 변경 가능, 개발 단계에서만 UI 제공)

---

# 4) 설치·실행
## 4.1 로컬
```bash
pip install streamlit pandas requests python-dateutil
streamlit run cloud_demos/fmw_streamlit_cloud_demo_v1_2.py
```
- **DRF 연동**: 실행 후 `BASE_URL` 입력 → **불러오기(실서버)**

## 4.2 Streamlit Cloud
1) 저장소 연결 → 앱 파일 선택(예: `cloud_demos/fmw_streamlit_cloud_demo_v1_2.py`)  
2) **Secrets**에 `BASE_URL="https://<YOUR-NGINX-HOST>"` 추가  
3) 배포

> 단일 파일 데모도 있음: `fmw_streamlit_cloud_demo_v1_2.py`

---

# 5) 화면 가이드 (빠른 사용)
## 5.1 홈
- App 타이틀 **fmw**, 오버뷰 카드(레코드 수/신규/업데이트/삭제/지연시간)

## 5.2 히스토리 관리
- 상단 **검색**(전역 LIKE)  
- 탭 3개: **신규/업데이트/삭제**  
- 좌측 슬라이더로 **비교 기준: N일 전** 선택

## 5.3 피처 상세
- 피처 선택 → **mode 분포**, **국가 Top10**, 상세 테이블

## 5.4 데이터 탐색
- **Mode/Country/Operator** 멀티 필터 → 결과 테이블 + 상위 피처 막대차트

## 5.5 추세(라인차트)
- 최근 N일 **created/updated/deleted** 라인차트 + 원자료 테이블

## 5.6 타임라인(피처/모델)
- 모델/그룹/피처 선택 → 날짜별 **C/U/D** 미니 라인차트 + **일자별 상세**(접이식)

## 5.7 개발자 모드(임시)
- **동기화 시간 설정**, **수동 동기화 버튼**(실서버 테스트용)
- 운영 전환 시 이 메뉴는 **비활성/삭제** 예정

---

# 6) 캐시/스냅샷 구조
- 캐시 파일: `.cache/fmw_all.csv`
- 스냅샷: `.cache/daily/YYYY-MM-DD.csv`
- 비교: 스냅샷(`N`일 전) vs 현재 캐시 → **CRUD** 계산

> 대용량 시 권장: **증분 스냅샷**(추가 예정), CSV 압축, 컬럼 최소화

---

# 7) DRF 연동
- **필수 엔드포인트**
  - `GET /api/v1/all` (CSV)
  - `GET /api/dev/runs/summary?days=N` (JSON, 추세)
- **선택(개발/운영)**
  - `POST /api/dev/sync` (전체), `POST /api/dev/sync/{feature_group}`
- **보안**: **Nginx IP Allowlist**, 앱은 **내부 바인딩**

---

# 8) QA · 체크리스트
- [ ] 홈/히스토리/상세/탐색/추세/타임라인 **모두 로드되는지**  
- [ ] **N일 비교** 숫자와 테이블이 일치하는지  
- [ ] CSV 헤더 순서가 **05 스펙**과 일치하는지  
- [ ] `mode` 값이 enum(`allow|block|none`)인지  
- [ ] 스냅샷이 `.cache/daily/`에 쌓이는지

---

# 9) 장애 대응 · 트러블슈팅
| 증상 | 원인 | 조치 |
|---|---|---|
| 화면 공백/로딩 | DRF 응답 지연 | 데모 모드로 먼저 확인, `BASE_URL` 점검 |
| 추세 0만 표시 | `/api/dev/runs/summary` 미구현 | 데모 **시뮬 폴백** 사용, 서버 구현 후 전환 |
| CRUD 계산 불일치 | 헤더/키 규칙 위반 | 05 스펙 확인, 고유 키·NULL 처리 재점검 |
| CSV 용량 큼 | 과도한 dims/필드 | 스키마 슬림화, 압축, 증분 스냅샷 고려 |

---

# 10) 파일 위치(현재)
- 데모 앱: `cloud_demos/fmw_streamlit_cloud_demo_v1_2.py`  
- 번들 ZIP: `fmw_streamlit_bundle_2025-10-24.zip`

---

# 11) 향후(로드맵)
- `/api/dev/changes`(타임라인 전용) 연동
- 증분 동기화/페이지네이션
- OIDC/RBAC, 감사로그
- taxonomy(명칭 표준화) 대시보드

---

# 12) 변경 이력
- v1.0 (2025-10-24): 초기 작성
