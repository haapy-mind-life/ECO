---
title: 00 — docs 폴더 구조 Overview (최신)
version: v1.0
updated: 2025-10-24
owner: 선생님
---

# 목적
- 문서/코드/스펙을 **한 눈에 찾고**, **버전·이력**을 명확히 관리합니다.
- 신규 합류자(우리팀 20명 → 그룹 확장 전제)도 **바로 쓸 수 있는 표준 맵**을 제공합니다.

# 네이밍 규칙 (권장)
```
<번호(00~99)>_<영문or한글_스네이크>_v<주버전>[ _YYYY-MM-DD ].<확장자>
예) 06_open_api_v1_2025-10-24.yaml
    03_architecture_overview_c4_v1.md
```
- 번호는 **정보 흐름** 순서(00 개요 → 01/02 드라이버 → 03 C4 → 04 PRD → 05 데이터 → 06 API …).
- 날짜는 **스냅샷가치**가 있을 때만 붙입니다(큰 변경 Release 기준).

# 권장 폴더 트리
```
/ (repo root)
├─ docs/                         # 모든 설계/운영 문서
│  ├─ 00_docs_폴더_구조_overview_v1_YYYY-MM-DD.md
│  ├─ 01_fmw_비즈니스_드라이버_vX.md
│  ├─ 02_아키텍처_드라이버_vX.md
│  ├─ 03_architecture_overview_c4_vX.md
│  ├─ 04_fmw_prd_vX.md
│  ├─ 05_feature_record_spec_vX.md
│  ├─ 06_open_api_vX.yaml
│  ├─ 07_streamlit_app_guide_vX.md
│  ├─ 08_db_schema_erd_vX.md
│  ├─ 09_ops_runbook_vX.md
│  └─ 10_release_notes_changelog.md
├─ app/                          # Streamlit 메인 앱
│  └─ streamlit_app.py
├─ cloud_demos/                  # 데모/POC 단일 파일들
│  ├─ fmw_streamlit_cloud_demo.py
│  ├─ fmw_streamlit_cloud_demo_v1_1.py
│  └─ fmw_streamlit_cloud_demo_v1_2.py
├─ specs/                        # API/스키마 명세 모음
│  └─ openapi/06_open_api_vX.yaml
├─ bundles/                      # 배포용/공유용 번들 ZIP
│  ├─ fmw_streamlit_full_v1_YYYY-MM-DD.zip
│  └─ fmw_streamlit_bundle_YYYY-MM-DD.zip
└─ .streamlit/                   # 클라우드/로컬 시크릿 템플릿
   └─ secrets.example.toml
```
> 현재 파일들이 루트(`/mnt/data`)에 혼재해 있습니다. **차주에 위 구조로 점진 이동**을 권장합니다(파일명은 유지하되 폴더만 이동).

# 문서 수명주기 (Draft → Review → Release)
1. **Draft**: `vX-draft`로 작성 → PR에서 팀 리뷰
2. **Review**: 코멘트 반영, 예제/스크린샷 보강
3. **Release**: `vX`로 승격 + 필요 시 날짜 스냅샷
4. **Deprecate**: 상위 버전 출현 시 이전 버전은 링크만 유지

# 권한/접근(요약)
- 외부 접근: Nginx **IP Allowlist**
- 내부: Django Admin(운영 1) / DB 운영(1) / 스트림릿 시각화(1) **초기 3인**
- Git 정적 페이지(위키/Q&A/공지)로 **업데이트 공유**

# 현재 보유 파일 맵 (자동 감지)
- [0_docs_폴더_구조_overview.md](sandbox:/mnt/data/0_docs_폴더_구조_overview.md)
- [02_아키텍처_드라이버_v_1.md](sandbox:/mnt/data/02_아키텍처_드라이버_v_1.md)
- [03_architecture_overview_c_4_v_1.md](sandbox:/mnt/data/03_architecture_overview_c_4_v_1.md)
- `06_open_api_스켈레톤_drf_기반_v_1.yaml` *(YAML, 일부 뷰어 미지원일 수 있음)* — /mnt/data/06_open_api_스켈레톤_drf_기반_v_1.yaml
- [fmw_비즈니스_드라이버_v_1.md](sandbox:/mnt/data/fmw_비즈니스_드라이버_v_1.md)
- [fmw_프로젝트_prd_v_1_2025_10_22.md](sandbox:/mnt/data/fmw_프로젝트_prd_v_1_2025_10_22.md)
- [fmw_프로젝트_prd_v_1.md](sandbox:/mnt/data/fmw_프로젝트_prd_v_1.md)
- [fmw_db_schema_erd_v_1_2025_10_22.md](sandbox:/mnt/data/fmw_db_schema_erd_v_1_2025_10_22.md)
- [2025-09-22-FMW PRD.md](sandbox:/mnt/data/2025-09-22-FMW PRD.md)
- [250926_FMW-PRD.md](sandbox:/mnt/data/250926_FMW-PRD.md)
- [DB 기초 개념 정리 1.md](sandbox:/mnt/data/DB 기초 개념 정리 1.md)
- [FMW 최소 DB 설계 1.md](sandbox:/mnt/data/FMW 최소 DB 설계 1.md)
- [fmw_streamlit_cloud_demo.py](sandbox:/mnt/data/fmw_streamlit_cloud_demo.py)
- [fmw_streamlit_cloud_demo_v1_1.py](sandbox:/mnt/data/fmw_streamlit_cloud_demo_v1_1.py)
- [fmw_streamlit_cloud_demo_v1_2.py](sandbox:/mnt/data/fmw_streamlit_cloud_demo_v1_2.py)
- [fmw_streamlit_bundle_2025-10-24.zip](sandbox:/mnt/data/fmw_streamlit_bundle_2025-10-24.zip)

# 다음 액션 체크리스트
- [ ] 루트에 있는 문서를 `docs/`로 이동(폴더 표준화)
- [ ] PRD 최신판 파일명 정리: `docs/04_fmw_prd_v1_YYYY-MM-DD.md`
- [ ] OpenAPI 파일 이동: `specs/openapi/06_open_api_v1_YYYY-MM-DD.yaml`
- [ ] `bundles/` 폴더에 ZIP 정리(날짜 유지)
- [ ] Git 정적 페이지(소개/FAQ/Q&A) 첫 버전 게시
