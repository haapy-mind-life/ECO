---
title: 03 — Architecture Overview (C4) — FMW
version: v1.0
updated: 2025-10-24
owner: 선생님
links:
  - 00_docs_폴더_구조_overview_v1_2025-10-24.md
  - 01_fmw_비즈니스_드라이버_v1_2025-10-24.md
  - 02_아키텍처_드라이버_v1_2025-10-24.md
audience: 개발팀 20명(1차), 운영 3인
---

# 1) 이 문서가 하는 일
- **한 장짜리로 전체 구조를 이해**하게 도와줍니다.
- C4 모델 레벨별(컨텍스트 → 컨테이너 → 컴포넌트)로 **쉽게** 설명합니다.
- 코드가 아니라 **어디서 무엇이 오가고**, **운영자는 어디를 보는지**를 중심으로 봅니다.

---

# 2) C1 — System Context (가장 큰 지도)
```
[사내 사용자(개발자 20명)]
        │  (사내망)
        ▼
    [Nginx Reverse Proxy]  ── IP Allowlist
        ├─ /streamlit/  →  [Streamlit UI]
        ├─ /api/...     →  [Django REST Framework(API)]
        ├─ /ops/        →  [운영자 대시보드(서버측)]
        └─ /admin/      →  [Django Admin]
(+ Git 정적 페이지: 소개/위키/Q&A/공지 링크 허브)
```
- **보안 기본**: 외부는 차단, **허용된 IP만** 접근.
- **사용 흐름**: 대부분의 개발자는 **Streamlit**으로 조회/검색, 운영자 3인은 ops/admin도 이용.

---

# 3) C2 — Containers (역할 상자)
```
+------------------+       +-------------------------------+
|   Nginx          |       |  Streamlit (UI, 사용자용)     |
|  - reverse proxy | <---> |  - DataManager(캐시/스냅샷)   |
|  - IP Allowlist  |  CSV  |  - 홈/히스토리/상세/탐색/추세 |
+------------------+       +-------------------------------+
         | REST API (CSV/JSON)
         v
+------------------+
| Django + DRF     |
| - /api/v1/all    |  (조회)
| - /api/v1/{fg} |
| - /api/dev/sync  |  (개발/수동 동기화)
| - /api/dev/runs/summary (추세)
| - /ops (운영자 UI) /admin (관리자) |
+------------------+

(데이터베이스/파일저장소는 DRF 뒤에서 관리)
```
- **데이터 전달 방식**: v1은 **CSV 벌크**가 기본(가볍고, 필드 순서 고정).
- **캐시 전략**: Streamlit이 하루 1회(기본 **06:00 KST**) DRF로부터 **한 번에** 받아서 저장.

---

# 4) C3 — Components (핵심 컴포넌트 역할)
## 4.1 Nginx
- **프록시 + 허용 IP만 통과**.
- 라우팅: `/streamlit/`, `/api/`, `/ops/`, `/admin/`

## 4.2 Django + DRF (서버)
- **Public API(v1)**:  
  - `GET /api/v1/all` — 전체 레코드, CSV 기본  
  - `GET /api/v1/{feature_group}` — 그룹별 조회
- **Dev/운영 API**:  
  - `POST /api/dev/sync` (전체), `POST /api/dev/sync/{feature_group}` (그룹)  
  - `GET /api/dev/runs/summary?days=N` — N일 추세(생성/업데이트/삭제 카운트)
- **운영 화면**:  
  - `ops/` (현황, 수동 동기화, 로그), `admin/` (Django 관리자)

## 4.3 Streamlit (클라이언트 UI)
- **DataManager**: `/api/v1/all` CSV를 **하루 1회** 받아 **.cache/** 저장 + **.cache/daily/** 스냅샷.  
- **화면**:
  1) **홈 오버뷰** — 레코드 수·스냅샷 수·오늘 변경/실패 run, 미니 추세  
  2) **히스토리 관리** — `N`일 전 대비 **CRUD**(신규/업데이트/삭제), 검색/다운로드  
  3) **피처 상세** — 선택한 모델/그룹/피처 분포 + 테이블  
  4) **데이터 탐색** — 자유 필터 + Top10  
  5) **추세(라인차트)** — 최근 `N`일 created/updated/deleted  
  6) **타임라인(피처/모델)** — 선택 기준의 일자별 변경 로그(시뮬/스냅샷 기반)  
  7) **개발자 모드(임시)** — 강제 동기화, 동기화 시각 설정

---

# 5) C4(간단) — 배포/네트워크 뷰
```
사내망(VPC)
 ├─ Nginx(Reverse Proxy, Public=사내) ── IP Allowlist
 │    ├─ 프록시 → Streamlit(127.0.0.1:8501 등 내부 바인딩)
 │    └─ 프록시 → Django/DRF(127.0.0.1:8000 등 내부 바인딩)
 └─ DB/스토리지(사설 네트워크, DRF만 접근)
```
- **외부 노출 최소화**: Streamlit/DRF는 내부 바인딩, Nginx만 사내망에 노출.

---

# 6) 주요 인터페이스 & URL 요약
- 사용자: `streamlit/`
- 운영자: `ops/` (대시보드), `admin/` (관리자)
- API: `GET /api/v1/all`, `GET /api/v1/{feature_group}`
- Dev: `POST /api/dev/sync`, `POST /api/dev/sync/{feature_group}`, `GET /api/dev/runs/summary`

---

# 7) 데이터 흐름(시퀀스)
```
[사용자] → Streamlit 접속
  Streamlit DataManager:
    1) 캐시 신선도 확인(06:00 KST 이후 첫 진입이면 새로 받기)
    2) 필요 시 DRF /api/v1/all CSV 벌크 로드
    3) .cache/fmw_all.csv 저장 + .cache/daily/YYYY-MM-DD.csv 스냅샷
  UI:
    - 홈 오버뷰에 수치·추세 표시
    - 히스토리: 이전 스냅샷과 비교해 CRUD 계산
    - 상세/탐색/타임라인: 선택 조건에 맞춰 표시
```

---

# 8) 품질 속성 매핑(02와 연결)
| 속성 | 설계 포인트 |
|---|---|
| 성능 | CSV 벌크 + 캐시, 페이지가 캐시로 즉시 렌더 |
| 보안 | Nginx IP Allowlist, 내부 바인딩 |
| 가용성 | 요약 API 실패 시에도 캐시/스냅샷으로 동작 |
| 변경 용이성 | Shallow-root API, 표준 스키마(필드 고정) |
| 관측성 | runs/summary, ops 화면, 스냅샷 파일 |

---

# 9) 데이터 스키마(요약, v1)
```
model_name, solution, feature_group, feature,
mcc, mnc, region, country, operator, sp_fci,
mode, value, sync_time
```
- 일부 **dims 없음 허용**(예: `mcc/mnc` 또는 `sp_fci` 없음 → NULL)

---

# 10) 운영 체크리스트
- [ ] Nginx IP 허용목록 최신화(팀/사내망 변화 반영)
- [ ] 06:00 KST 스냅샷 정상 생성 확인
- [ ] ops/에서 동기화/실패 run 모니터링
- [ ] Git 정적 페이지(소개/Q&A/배포 노트) 업데이트

---

# 11) 다음 단계(확장)
- **증분 동기화**(delta, 페이지네이션)
- **변경 로그 API**(`/api/dev/changes`) 설계/연동
- **인증/권한**(OIDC/RBAC) 도입
- **taxonomy**(명칭 표준화) 운영 대시보드

---

# 12) 변경 이력
- v1.0 (2025-10-24): 초기 작성
