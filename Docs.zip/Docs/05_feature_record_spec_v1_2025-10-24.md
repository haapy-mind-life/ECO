---
title: 05 — Feature Record 스펙 (FMW)
version: v1.0
updated: 2025-10-24
owner: 선생님
links:
  - 01_fmw_비즈니스_드라이버_v1_2025-10-24.md
  - 02_아키텍처_드라이버_v1_2025-10-24.md
  - 04_fmw_prd_v1_2025-10-24.md
audience: 개발팀 20명(1차), 운영 3인
---

# 1) 목적(쉬운 요약)
- **한 줄**: 피처 한 건을 **레코드 한 줄**로 표준화합니다.  
- 어디서든 같은 규칙으로 읽고(드리븐), 비교하고(CRUD), 시각화(Streamlit)할 수 있게 합니다.

---

# 2) 표준 레코드 구조(필수 헤더 순서)
```
model_name, solution, feature_group, feature,
mcc, mnc, region, country, operator, sp_fci,
mode, value, sync_time
```
- `model_name`: 예) `S20`, `S21` …
- `solution`: 예) `slsi`, `mtk` *(초기 2종, 확장 가능)*
- `feature_group` → `feature`: 예) `Connectivity/VoLTE`
- `dims`(상황 차원): `mcc, mnc, region, country, operator, sp_fci` *(없을 수 있음 → NULL)*
- `mode`: `allow | block | none`
- `value`: 실제 설정값(불리언/숫자/문자 등)
- `sync_time`: `ISO-8601` 타임스탬프(KST 권장)

> **호환성**: 기존 문서/코드에서 `svc profile` 같은 여러 이름이 혼재되어 있으므로, 본 스펙은 **열 이름을 `sp_fci`로 표준화**합니다.  
> 필요 시 **별칭(alias)** 지원: `svc_profile, svc, profile, sp` → `sp_fci`로 매핑.

---

# 3) 필드 정의(간단)
| 필드 | 타입 | 예시 | 규칙 |
|---|---|---|---|
| model_name | string | S20 | 필수 |
| solution | enum | slsi, mtk | 필수 |
| feature_group | string | Connectivity | 필수(초기: Connectivity, Messaging, Data, Roaming) |
| feature | string | VoLTE | 필수(그룹 내 3~5개 수준부터 시작) |
| mcc | string? | 450 | 없음 허용(NULL) |
| mnc | string? | 05 | 없음 허용(NULL), 2~3자리 zero-pad 권장 |
| region | enum? | APAC/EU/NA… | 없음 허용(NULL) |
| country | ISO-2? | KR | 없음 허용(NULL) |
| operator | string? | SKT | 없음 허용(NULL) |
| sp_fci | string? | postpaid | 없음 허용(NULL), *(명칭 표준화 필요)* |
| mode | enum | allow/block/none | 필수 |
| value | any | true, 42, level-3 | 필수(타입 자유, 문자열 비교 기준) |
| sync_time | datetime | 2025-10-24T06:00:00+09:00 | 필수(스냅샷 시각) |

---

# 4) 고유 키 & 중복 규칙
- **비즈니스 키**(고정):  
  `model_name|solution|feature_group|feature|mcc|mnc|region|country|operator|sp_fci|mode`
- **중복 금지**: 동일 키에 **둘 이상의 레코드 금지**.  
- **충돌 처리**: 동일 키에서 `value`가 다르면 **최근 sync_time** 우선(= 같은 날이면 **소스 우선순위** 규칙 적용).

---

# 5) 모드 해석(allow/block/none)
- **allow**: 해당 조건에서 **허용**
- **block**: 해당 조건에서 **차단**
- **none**: 정책 미정/상속(후순위 규칙 적용)

> **우선순위(결정 트리)**  
> ① **가장 구체적인 dims** 매칭(아래 **§6 매칭/우선순위** 참고) → ② mode 충돌 시 **block이 우선** → ③ 값 충돌 시 **최근 sync_time**

---

# 6) 매칭/우선순위(핵심 규칙)
dims는 **있을 수도/없을 수도** 있습니다. 쿼리 시 **가장 구체적인(= non-NULL이 많은)** 레코드를 선택합니다.

1. **특이성 점수(S)** = `non-NULL dims 개수`  
   - 예) `mcc,mnc,country=KR` 3개 → S=3
2. **우선순위(동점 시)**  
   - `mcc+mnc` > `mcc` > `operator` > `country` > `region` > `sp_fci`
   - 동점이면 `sync_time` 최신 우선
3. **와일드카드**: NULL은 **모든 값과 매칭**(= 기본 정책)

> 예시 매칭(질의: `model=S20, feature=VoLTE, mcc=450, mnc=05`)  
> - 후보 A: `mcc=450, mnc=05` → S=2 (**최우선**)  
> - 후보 B: `country=KR` → S=1  
> - 후보 C: `region=APAC` → S=1  
> 최종: A 선택. 동점일 경우 위의 **우선순위**로 결정.

---

# 7) 값 타입/검증(가볍게)
- **bool 계열**: `true/false`, `on/off`, `1/0` → **문자열 기준**으로 비교하되, UI에서 친화적으로 표기
- **수치 계열**: 숫자 또는 `level-<n>` 형태(예: `level-3`) 허용
- **문자 계열**: 임의 문자열 허용(공백/한글 포함), CSV 안전 문자권장
- **검증**: Streamlit 업로드/동기화 시 **헤더·필수값** 체크, `mode` enum 확인

---

# 8) 명칭 표준화(taxonomy)
- **문제**: `SVC profile`/지역/사업자 명칭이 혼재(`EU`, `sp white`, `global`, `KDDI` 등)
- **해결**: `taxonomy.yaml`에 **표준명 ↔ 원본명 목록** 유지, 로딩 시 **정규화** → `sp_fci`/`country`/`operator`…

예시(`taxonomy.yaml`):
```yaml
sp_fci:
  postpaid: [postpaid, ppost, white, sp white]
  prepaid: [prepaid, pre]
  mvno: [mvno, virtual]
operator:
  KDDI: [KDDI, au, au_KDDI]
country:
  KR: [Korea, KOR, Republic of Korea]
region:
  EU: [EU, Europe]
```

---

# 9) 샘플 CSV (10행 축약)
```csv
model_name,solution,feature_group,feature,mcc,mnc,region,country,operator,sp_fci,mode,value,sync_time
S20,slsi,Connectivity,VoLTE,450,05,APAC,KR,SKT,,allow,true,2025-10-24T06:00:00+09:00
S20,slsi,Connectivity,VoLTE,,,APAC,KR,SKT,postpaid,block,false,2025-10-24T06:00:00+09:00
S21,mtk,Data,Hotspot,,,,DE,VODAFONE,postpaid,block,level-3,2025-10-24T06:00:00+09:00
S22,slsi,Messaging,SMS,,,,KR,SKT,,allow,true,2025-10-24T06:00:00+09:00
S23,mtk,Roaming,Roaming,440,50,,JP,DOCOMO,mvno,allow,true,2025-10-24T06:00:00+09:00
S24,slsi,Data,Throttle,,,,US,VERIZON,,block,50,2025-10-24T06:00:00+09:00
S25,mtk,Connectivity,5G_NSA,,,,GB,VODAFONE,,allow,true,2025-10-24T06:00:00+09:00
S26,slsi,Data,DualSIM,,,,KR,LGU+,corp,allow,true,2025-10-24T06:00:00+09:00
S27,mtk,Connectivity,VoWiFi,450,08,,,SKT,,block,false,2025-10-24T06:00:00+09:00
S28,slsi,Roaming,RoamVoLTE,,,APAC,SG,SINGTEL,vip,allow,true,2025-10-24T06:00:00+09:00
```

---

# 10) API 응답 계약(CSV, v1)
- `/api/v1/all` **CSV** 헤더는 §2와 **동일 순서**여야 합니다.
- 그룹별: `/api/v1/{feature_group}`도 동일 스키마 유지.
- 컨텐츠 타입: `text/csv; charset=utf-8`

---

# 11) 동기화/스냅샷
- 기본: **하루 1회**(KST 06:00) 전체 CSV 벌크 수집
- 개발자 전용: `/api/dev/sync`, `/api/dev/sync/{feature_group}` 수동 트리거
- Streamlit: `.cache/fmw_all.csv` + `.cache/daily/YYYY-MM-DD.csv`로 보관

---

# 12) 개발 체크리스트
- [ ] CSV 헤더 순서 준수(§2)  
- [ ] `mode` 값이 enum에 포함되는지 확인  
- [ ] dims NULL 처리(없으면 공란/NULL)  
- [ ] 동일 키 중복/충돌 방지(§4)  
- [ ] taxonomy 적용/로그(미매핑 목록 집계)  
- [ ] 성능: 5만 행 기준 홈 < 2초(캐시) 목표

---

# 13) 변경 이력
- v1.0 (2025-10-24): 초기 스펙 작성 (dims 누락 허용, 표준 키, 우선순위 규칙 포함)
