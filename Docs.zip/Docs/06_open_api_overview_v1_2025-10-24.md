---
title: 06 — Open API 개요(v1) — DRF 기반
version: v1.0
updated: 2025-10-24
owner: 선생님
links:
  - 04_fmw_prd_v1_2025-10-24.md
  - 05_feature_record_spec_v1_2025-10-24.md
---

# 1) 목적(한 줄)
**Streamlit DataManager**가 하루 1회 가져갈 **CSV 벌크 API**와, 운영/개발 편의를 위한 **DEV 요약/싱크 API**를 정의합니다.

---

# 2) 기본 원칙
- **버전 경로**: `/api/v1/...` (호환 깨질 때 `/api/v2/...` 준비)
- **콘텐츠 타입**: **CSV 우선** (`text/csv; charset=utf-8`), 요약/메타는 JSON
- **보안**: Nginx **IP Allowlist**, DRF/Streamlit **내부 바인딩**
- **성능**: 실시간 과호출 금지 → **하루 1회 벌크 + 캐시**(필요 시 dev 수동 싱크)

---

# 3) 엔드포인트 요약
| 경로 | 메서드 | 설명 | 응답 |
|---|---|---|---|
| `/api/v1/all` | GET | **전체 레코드** CSV | `text/csv` |
| `/api/v1/{feature_group}` | GET | **그룹별** 레코드 CSV | `text/csv` |
| `/api/dev/sync` | POST | **전체 동기화 트리거**(개발/운영) | `application/json` |
| `/api/dev/sync/{feature_group}` | POST | **그룹 동기화 트리거** | `application/json` |
| `/api/dev/runs/summary?days=N` | GET | **최근 N일 추세 요약** | `application/json` |

> UI 경로: `ops/`(운영 대시보드), `admin/`(Django 관리자), `streamlit/`(사용자 UI)

---

# 4) CSV 스키마(헤더 순서)
```
model_name, solution, feature_group, feature,
mcc, mnc, region, country, operator, sp_fci,
mode, value, sync_time
```
- **dims 누락 허용**: `mcc/mnc` 또는 `sp_fci`가 비어도 OK (`NULL`)
- 자세한 의미는 **05 문서** 참고

샘플(2행):
```csv
model_name,solution,feature_group,feature,mcc,mnc,region,country,operator,sp_fci,mode,value,sync_time
S20,slsi,Connectivity,VoLTE,,,APAC,KR,SKT,,allow,true,2025-10-24T06:00:00+09:00
S21,mtk,Data,Hotspot,,,EU,DE,VODAFONE,postpaid,block,level-3,2025-10-24T06:00:00+09:00
```

---

# 5) 쿼리 파라미터(선택)
- 공통 필터(선택): `model_name, solution, feature_group, feature, mcc, mnc, region, country, operator, sp_fci, mode`
- 기간 필터(선택): `since=YYYY-MM-DD` *(해당 일자 이후 데이터만)*
- 정렬(선택): `sort=field1,-field2` *(초기 미구현이면 무시 가능 — 서버는 CSV 고정 순서로 반환)*

> **주의**: v1은 **CSV 벌크**가 기본이므로, 필터가 과도하면 응답 시간이 늘 수 있습니다. 기본은 **무필터 전체**를 권장합니다.

---

# 6) 에러 규칙(요약)
| 코드 | 의미 | 예시 |
|---|---|---|
| 400 | 잘못된 파라미터 | days 음수, feature_group 오타 |
| 401/403 | 인증/권한 | (초기엔 IP Allowlist로 차단) |
| 429 | 과도한 요청 | 빈번한 dev sync 호출 |
| 5xx | 서버 오류 | 내부 예외/시간초과 |

---

# 7) 예시 호출
```bash
# 전체 CSV
curl -H "Accept: text/csv" https://<host>/api/v1/all -o fmw_all.csv

# 그룹 CSV
curl -H "Accept: text/csv" https://<host>/api/v1/Connectivity -o connectivity.csv

# 최근 7일 요약(JSON)
curl https://<host>/api/dev/runs/summary?days=7

# 전체 동기화 트리거
curl -X POST https://<host>/api/dev/sync -H "Content-Type: application/json" -d '{"reason":"manual-test"}'
```
