from __future__ import annotations
import streamlit as st

def render_visualization():
    st.title("📈 시각화")
    st.info("선택한 그룹/피처 기준의 차트 템플릿은 차기 버전에서 연결합니다. (예: 모드별 분포, 지역/사업자 피벗)")
